---
name: app-audit
description: Full defensive audit of an app or website the user owns. Maps every page, route, API endpoint, button, form and link; starts the app and clicks everything at desktop (1440px) and phone (390px) size; checks the backend and security against an OWASP-based checklist; writes AUDIT.md with severity, file:line and fix; fixes all critical and high findings and re-tests each fix. Use when the user says "audit my app", "app audit", "check my site for bugs/security", "click-test everything", or runs /app-audit.
---

# App audit

You audit and fix an app **the user owns**. Defensive work only.

## Rules (read first)

1. **Own apps only.** Work on code in the user's project and on a copy running on
   localhost. If the target is a live URL, ask "Is this your own site?" before any
   request. Never test a site the user does not own. The dynamic scripts refuse
   non-local hosts unless you pass `--i-own-this`: only pass it after the user said yes.
2. **Test data only.** The click test really clicks and submits. Use a dev database
   and test users. Never run it against production data.
3. **Prove it or list it.** A finding is real only when you have seen it (a failing
   request, a line of code, a screenshot). Everything you could not test goes in the
   **NOT VERIFIED** list in AUDIT.md with the reason. Never write "looks fine".
4. **Never print a full secret.** In AUDIT.md show the first 4 characters and `...`.
5. **Small fixes.** Fix the bug, do not rewrite the app. One fix at a time, test after each.
6. **Do not commit or push** unless the user asks.
7. Simple English in the report. Short sentences.

## Files in this skill

| file | use |
|---|---|
| `checklist.md` | every check, with how to test it and the OWASP source |
| `report-template.md` | copy this to make `AUDIT.md` |
| `scripts/map_app.py` | step 1: stack, routes, forms, buttons, links from the code |
| `scripts/click_audit.py` | step 2: real browser, clicks everything, two screen sizes |
| `scripts/scan_code.py` | step 3: risky code patterns + secrets in code and git history |
| `scripts/check_http.py` | step 3: headers, cookies, CORS, error leaks, login lockout |
| `scripts/access_check.py` | step 3: can user B open user A's data? |
| `scripts/probe_inputs.py` | step 3: confirms SQL injection and XSS on one form |

Scripts need Python 3.8+. Only `click_audit.py` needs an extra package
(`pip install playwright` then `python -m playwright install chromium`).
On Windows use `python`, on Linux/Mac `python3`. `SK` below = this skill's `scripts` folder.
All scripts write into `audit-out/` (add it to `.gitignore`).

## Step 0 - Get ready

- Read the README and the start command. Find how to run the tests.
- Make sure the app uses a **dev database**. Make or find two normal test users
  (A and B) and, if the app has roles, one admin. Take passwords from seed/fixture
  files. Pass them by environment variable (`AUDIT_PASSWORD`, `AUDIT_PASSWORD_A`,
  `AUDIT_PASSWORD_B`), never write them in the report.
- Run the existing tests once and note the result (this is the "before" state).
- Copy `report-template.md` to `AUDIT.md` in the project root.

## Step 1 - Map the app

```
python SK/map_app.py . --out audit-out
```

Read `audit-out/MAP.md`. The script is a helper, not the truth: **open the router,
controller and template files yourself** and add what it missed (routes made in
loops, API calls from JavaScript `fetch`, pages behind login, admin pages).
Put the final map in AUDIT.md section 1. Count: pages, API endpoints, forms, buttons.

## Step 2 - Start the app and click everything

Start the app (background), wait until it answers, then:

```
python SK/click_audit.py --base http://localhost:PORT --login-url /login --username USER_A
```

- It runs at **1440px and 390px**, visits every linked page, clicks every button,
  fills and submits every form, and records console errors and failed requests.
- Run it twice if needed: once logged out, once logged in (and once as admin).
- Pages nobody links to: pass them with `--start /path1 /path2` (take them from the map).
- If Playwright cannot be installed, do this step by hand with the browser tools
  (resize to 1440 and 390 wide) and say so in NOT VERIFIED.

Then look yourself (screenshot each main page at both sizes): overlapping text,
cut-off buttons, menus that cannot be opened on phone, things the script cannot judge.

What counts as a bug:

| problem | how you know |
|---|---|
| dead button | click gives no navigation, no request, no page change |
| duplicate buttons | two buttons submit the same form / call the same handler / same request |
| dead link | HTTP 404/500, `href="#"`, or anchor to a missing id |
| broken form | submit answers 4xx/5xx with valid data, or nothing is saved |
| console error | any error in the browser console or a failed request |
| phone layout | sideways scroll at 390px, element hidden or impossible to tap |

Copy `audit-out/UI_TABLE.md` rows that are not "ok" into AUDIT.md section 2
(`screen | element | expected | result | fixed?`). Keep the full table in `audit-out/`.
Fix each UI bug (remove or wire the dead button, remove the duplicate, fix or remove
the dead link), then **run the click test again** and set `fixed?` to yes only when
the row is gone.

## Step 3 - Backend and security checks

Run the helpers, then go through `checklist.md` **line by line**. Every checklist
line ends as one of: PASS, FINDING, NOT APPLICABLE (say why), NOT VERIFIED (say why).

```
python SK/scan_code.py . --out audit-out
python SK/check_http.py --base http://localhost:PORT --paths / /login --login /login --user USER_A --lockout-test 12
python SK/access_check.py --base http://localhost:PORT --login /login --user-a USER_A --user-b USER_B --paths /thing/ID_OF_A ...
python SK/probe_inputs.py --base http://localhost:PORT --path /login --method POST --params username password
```

- `scan_code.py` gives **leads**. Open each file:line and decide: real, or false alarm.
- `access_check.py`: take the paths from the map ("ACCESS" leads and every route with
  an id). Use ids that belong to user A. Test admin pages with a normal user too.
  For write actions (POST/PUT/DELETE on another user's item) test by hand with care.
- `probe_inputs.py`: run it on **every form and every URL parameter** that reaches the
  database or is shown back on a page (login, search, create, edit, comment).
- Dependencies: run the tool for the stack and read the output:
  `pip-audit` / `npm audit` / `composer audit` / `bundle audit`. Tool missing and
  cannot install it -> NOT VERIFIED.
- Things only the user knows (backups, hosting, CDN, HTTPS on the real server,
  monitoring): **ask the user**. No answer -> NOT VERIFIED. Do not guess.

## Step 4 - Find what the checklist is missing

After the checklist, think about **this** app: what can go wrong here that no line
covers? (payments, file sharing, invite links, password reset, WebSockets, AI
features, mobile API, multi-tenant data...). Check the OWASP Top 10, OWASP ASVS and
the OWASP Cheat Sheet index for that feature.
**If you find a gap, add a new line to `checklist.md`** (section Z, with date and
source) so the next audit has it for good. Tell the user what you added.

## Step 5 - Write AUDIT.md

Use `report-template.md`. One row per finding:
`ID | severity | title | file:line | proof | fix | fixed? | re-test`.

Severity guide:

| severity | meaning | examples |
|---|---|---|
| critical | attacker gets in or gets data now | SQL injection, login bypass, live secret in code, remote code run |
| high | serious, needs one more step or a logged-in user | stored/reflected XSS, user A reads user B's data, no CSRF on important actions, plain-text passwords, debug mode on, no login lockout |
| medium | makes attacks easier or hurts users | missing security headers, weak cookie flags, no rate limit elsewhere, error leaks, dead/duplicate buttons, broken form, no backups |
| low | good practice, polish | version in headers, missing alt text, no CI, slow page |

Same bug in five places = one finding with five locations.

## Step 6 - Fix critical and high, then prove it

For each critical and high finding, in order of severity:

1. Write the smallest correct fix (see "Fix" column in `checklist.md`).
2. Add or update a test that fails before the fix and passes after, when the project has tests.
3. Run the whole test suite.
4. **Re-run the exact check that found it** (same script, same input) and paste the
   new result in the `re-test` column. `fixed? = yes` only with a passing re-test.
5. A secret found in code or git history: moving it to an env variable is not enough.
   Tell the user to **rotate it** (make a new one). You cannot do that for them: list it.

Medium and low: fix the quick ones if the user agrees, list the rest as "open".
At the end run the click test and the full test suite one last time.

## Step 7 - Final answer to the user

Short summary: number of findings per severity, what was fixed, what is still open,
the NOT VERIFIED list, and what the user must do by hand (rotate secrets, set up
backups, turn on HTTPS...). Point to AUDIT.md.
