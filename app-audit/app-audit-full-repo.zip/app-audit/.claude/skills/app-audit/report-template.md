# AUDIT - <app name>

- Date: <YYYY-MM-DD>
- Commit / version: <git hash or "no git">
- Audited by: Claude Code, skill `app-audit`
- Scope: <folder>, running at <http://localhost:PORT>, test users: <A>, <B>, <admin?>
- Tests before audit: <X passed, Y failed> - after: <X passed, Y failed>

## Summary

| severity | found | fixed | open |
|---|---|---|---|
| critical | | | |
| high | | | |
| medium | | | |
| low | | | |

Top 3 things to know: <one line each>

## 1. App map

Stack: <language, framework, API style, database, auth, hosting>

| methods | path | page / API | needs login? | owner or role check? | file:line |
|---|---|---|---|---|---|

Counts: <n> pages, <n> API endpoints, <n> forms, <n> buttons, <n> links.

## 2. UI click test (desktop 1440px + phone 390px)

Only rows that are not OK. Full table: `audit-out/UI_TABLE.md`.

| screen | element | expected | result | fixed? |
|---|---|---|---|---|

## 3. Findings

| ID | severity | title | file:line | proof (how it was seen) | fix | fixed? | re-test result |
|---|---|---|---|---|---|---|---|
| F-01 | critical | | | | | yes/no | |

Details for the hard ones (what an attacker could do, the code before and after).

## 4. Checklist result

One line per checklist ID: PASS / FINDING (F-xx) / NOT APPLICABLE (why) / NOT VERIFIED (why).

| ID | check | result |
|---|---|---|
| B1 | Server language and framework | |

## 5. NOT VERIFIED

Things that could not be tested, and why. Be honest: an empty list is suspicious.

| what | why not | how the owner can check it |
|---|---|---|

## 6. Your to-do list (things only you can do)

- [ ] Rotate these secrets: ...
- [ ] ...

## 7. Added to the checklist during this audit

- <new checklist lines, or "nothing new">
