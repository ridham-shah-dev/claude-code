#!/usr/bin/env python3
"""Static code scan: finds risky patterns with file and line.

Usage: python scan_code.py <app-folder> [--out audit-out]

Every hit is a LEAD, not proof. Read the code and confirm before you report it.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import md_cell, read_text, walk_files  # noqa: E402

CODE = {".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".php", ".rb", ".go", ".java", ".cs"}
TPL = {".html", ".htm", ".jinja", ".jinja2", ".j2", ".ejs", ".hbs", ".vue", ".svelte", ".twig",
       ".erb", ".php", ".jsx", ".tsx", ".js", ".ts"}
CONF = {".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".conf", ".env", ".sh", ".xml"}
SQLW = r"(?:SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM)\b"

# (id, severity, title, extensions, regex, fix)
RULES = [
    # ---- SQL injection -------------------------------------------------
    ("SQLI", "critical", "SQL built with an f-string", {".py"},
     r"""\bf(?:"[^"\n]*""" + SQLW + r"""[^"\n]*\{|'[^'\n]*""" + SQLW + r"""[^'\n]*\{)""",
     "Use parameters: execute('... WHERE x = ?', (value,))"),
    ("SQLI", "critical", "SQL built with string joining or format", CODE,
     r"""(?:"[^"\n]*""" + SQLW + r"""[^"\n]*"|'[^'\n]*""" + SQLW + r"""[^'\n]*')\s*(?:\+|%\s*[\w(]|\.format\()""",
     "Use parameterized queries / prepared statements"),
    ("SQLI", "critical", "SQL built with a JS template string", {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"},
     r"`[^`\n]*" + SQLW + r"[^`\n]*\$\{",
     "Use placeholders (?, $1) and pass values separately"),
    ("SQLI", "critical", "SQL with a PHP variable inside the string", {".php"},
     r"""["'][^"'\n]*""" + SQLW + r"""[^"'\n]*(?:\$\w+|\{\$)""",
     "Use PDO prepared statements with bound parameters"),
    ("SQLI", "high", "execute() called with joined text", CODE,
     r"""\.(?:execute|executemany|query|raw)\(\s*[^,)\n]*(?:["']\s*\+|\+\s*["']|%\s*\(|\.format\()""",
     "Pass values as parameters, never inside the SQL text"),
    # ---- XSS -----------------------------------------------------------
    ("XSS", "high", "Template output marked safe (no escaping)", TPL,
     r"\|\s*safe\b|\{%\s*autoescape\s+(?:false|off)|\{\{\{[^}]+\}\}\}|<%-\s|\{!!.+!!\}",
     "Remove it and let the template engine escape the value"),
    ("XSS", "high", "Raw HTML written from JavaScript", TPL,
     r"\.innerHTML\s*\+?=|\.outerHTML\s*=|document\.write(?:ln)?\(|insertAdjacentHTML\(|dangerouslySetInnerHTML|\bv-html\s*=|\{@html\s",
     "Use textContent, or sanitize with DOMPurify"),
    ("XSS", "high", "User input echoed without escaping", {".php"},
     r"(?:echo|print)\s+[^;\n]*\$_(?:GET|POST|REQUEST|COOKIE)",
     "Wrap with htmlspecialchars($x, ENT_QUOTES, 'UTF-8')"),
    ("XSS", "high", "Template escaping switched off in code", {".py"},
     r"\bMarkup\(|render_template_string\(|autoescape\s*=\s*False|mark_safe\(",
     "Do not build HTML from user input; keep autoescape on"),
    # ---- Secrets -------------------------------------------------------
    ("SECRET", "critical", "Secret written in the code", CODE | CONF,
     r"""(?i)\b[\w.]*(?:secret|api_?key|apikey|token|passw(?:or)?d|pwd|private_?key|auth_?key|access_?key)[\w.]*["']?\s*[:=]\s*["'][^"'\s{}<>]{8,}["']""",
     "Move it to an environment variable, then ROTATE the secret (it is burned)"),
    ("SECRET", "critical", "Known secret format (cloud / API key)", None,
     r"AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{36,}|sk_live_[0-9a-zA-Z]{16,}|xox[baprs]-[0-9A-Za-z-]{10,}|AIza[0-9A-Za-z_\-]{35}|-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----|sk-ant-[A-Za-z0-9_\-]{20,}",
     "Revoke the key now, create a new one, load it from the environment"),
    ("SECRET", "high", "Password inside a connection URL", None,
     r"\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|amqp)://[^:/\s\"']+:[^@\s\"']{3,}@",
     "Read the database URL from an environment variable"),
    # ---- Config / misc -------------------------------------------------
    ("DEBUG", "high", "Debug mode switched on", CODE | CONF,
     r"\bdebug\s*=\s*True\b|\bDEBUG\s*=\s*True\b|APP_DEBUG\s*=\s*true|FLASK_DEBUG\s*=\s*1|display_errors\s*=\s*(?:On|1)",
     "Turn debug off outside your own machine; read it from an env variable"),
    ("CRYPTO", "high", "Weak hash (MD5 / SHA1)", CODE,
     r"\b(?:md5|sha1)\s*\(|hashlib\.(?:md5|sha1)\(|createHash\(\s*[\"'](?:md5|sha1)[\"']",
     "Passwords: bcrypt / argon2 / scrypt. Other uses: SHA-256"),
    ("AUTH", "high", "Password compared as plain text", CODE,
     r"""(?i)passw(?:or)?d\w*\s*={2,3}\s*\w|passw(?:or)?d\s*=\s*'\{|AND\s+passw(?:or)?d\s*=""",
     "Store only a password hash and verify with the hash library"),
    ("TLS", "high", "TLS certificate check switched off", CODE,
     r"verify\s*=\s*False|rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED|CURLOPT_SSL_VERIFYPEER\s*,\s*(?:false|0)",
     "Keep certificate checking on"),
    ("CORS", "medium", "CORS open to every site", CODE | CONF,
     r"""Access-Control-Allow-Origin["']?\s*[,:)]\s*["']\*|origins?\s*[:=]\s*["']\*["']|CORS\(\s*\w+\s*\)|cors\(\s*\)""",
     "List the exact origins that may call your API"),
    ("RCE", "critical", "Code or shell run from text", CODE,
     r"\beval\(|\bexec\(\s*[^)]|os\.system\(|shell\s*=\s*True|child_process|\bpopen\(|shell_exec\(|passthru\(|pickle\.loads?\(|yaml\.load\((?![^)]*Safe)|unserialize\(\s*\$_",
     "Never pass user input to eval/shell/deserialize; use safe APIs with argument lists"),
    ("COOKIE", "medium", "Cookie safety flag switched off", CODE | CONF,
     r"(?i)httponly\s*[:=]\s*false|secure\s*[:=]\s*false|SESSION_COOKIE_(?:SECURE|HTTPONLY)\s*=\s*False|samesite\s*[:=]\s*[\"']?none",
     "Set HttpOnly, Secure and SameSite=Lax (or Strict) on session cookies"),
    ("RANDOM", "medium", "Weak random used near a token or password", CODE,
     r"(?i)(?:token|secret|password|otp|code|session)\w*\s*=.*(?:Math\.random\(|random\.(?:random|randint|choice)\()",
     "Use secrets.token_urlsafe() / crypto.randomBytes()"),
    ("REDIRECT", "medium", "Redirect target comes from the request", CODE,
     r"redirect\(\s*(?:request\.(?:args|form|GET|POST|values)|req\.(?:query|body|params)|\$_(?:GET|POST|REQUEST))",
     "Only redirect to paths on your own site (allow-list)"),
    ("UPLOAD", "medium", "File upload: check type, size and name handling", CODE,
     r"request\.files|\.save\(\s*(?:os\.path\.join\()?[^)]*filename|multer\(|\$_FILES|move_uploaded_file\(",
     "Allow-list extensions, limit size, rename the file, store outside the web root"),
    ("PATH", "medium", "File path built from the request", CODE,
     r"(?:open|send_file|sendFile|readFile(?:Sync)?|include|require)\(\s*[^)\n]*(?:request\.(?:args|form|values)|req\.(?:query|params|body)|\$_(?:GET|POST|REQUEST))",
     "Never use user input as a file path; map ids to files on the server"),
    ("ERRLEAK", "medium", "Error details sent to the user", CODE,
     r"return\s+str\(\s*e(?:rr|x|xc)?\s*\)|res\.(?:send|json)\(\s*(?:err|error|e)(?:\.stack|\.message)?\s*\)|traceback\.format_exc\(\)|echo\s+\$e->getMessage\(\)",
     "Show a generic error page; log the details on the server only"),
    ("SSRF", "medium", "Server fetches a URL taken from the request", CODE,
     r"(?:requests\.(?:get|post)|urlopen|fetch|axios\.(?:get|post)|file_get_contents|curl_init)\(\s*(?:request\.(?:args|form|values|json)|req\.(?:query|body|params)|\$_(?:GET|POST|REQUEST))",
     "Allow-list hosts; block private IP ranges"),
    ("HTTP", "low", "Plain http:// link to another site", TPL,
     r"""(?:src|href|action)\s*=\s*["']http://(?!localhost|127\.0\.0\.1)""",
     "Use https://"),
    ("BLANK", "low", "target=_blank without rel=noopener", TPL,
     r"""<a\b(?![^>]*\brel\s*=)[^>]*target\s*=\s*["']_blank["']""",
     'Add rel="noopener noreferrer"'),
]
COMPILED = [(i, s, t, e, re.compile(r), f) for i, s, t, e, r, f in RULES]
PLACEHOLDER = re.compile(
    r"(?i)changeme|change[-_ ]me|your[-_ ]|example|placeholder|xxxx|<[^>]+>|\$\{|\{\{|os\.environ|getenv|process\.env|dummy|redacted|\*\*\*\*")
SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def scan_file(path, rel):
    ext = os.path.splitext(path)[1].lower()
    name = os.path.basename(path)
    is_env = name == ".env" or name.startswith(".env.")
    is_test = bool(re.search(r"(^|/)(tests?|__tests__|spec|fixtures?)(/|$)|(^|/)test_|\.(test|spec)\.", rel))
    hits = []
    if is_env and not re.search(r"example|sample|template", name):
        hits.append(dict(id="SECRET", severity="high", title=".env file is inside the project",
                         file=rel, line=1, code=name,
                         fix="Add .env to .gitignore; check it was never committed (scan_git)"))
    lines = read_text(path).splitlines()
    for no, line in enumerate(lines, 1):
        if len(line) > 600 or "app-audit: ignore" in line:
            continue
        for rid, sev, title, exts, rx, fix in COMPILED:
            if exts is not None and ext not in exts and not is_env:
                continue
            if rid in ("XSS", "HTTP", "BLANK") and ext in {".js", ".ts"} and "innerHTML" not in line \
                    and "document.write" not in line and "insertAdjacentHTML" not in line:
                continue
            m = rx.search(line)
            if not m:
                continue
            if rid == "SECRET" and PLACEHOLDER.search(m.group(0)):
                continue
            s = sev
            note = ""
            if is_test:
                s, note = "low", " (test file: probably test data)"
            hits.append(dict(id=rid, severity=s, title=title + note, file=rel, line=no,
                             code=line.strip()[:160], fix=fix))
    return hits


def scan_git_history(root):
    """Look for secrets that were committed in the past (even if deleted later)."""
    if not shutil.which("git"):
        return None, "git is not installed"
    if not os.path.isdir(os.path.join(root, ".git")):
        probe = subprocess.run(["git", "-C", root, "rev-parse", "--is-inside-work-tree"],
                               capture_output=True, text=True)
        if probe.returncode != 0:
            return None, "folder is not a git repository"
    out = subprocess.run(["git", "-C", root, "log", "-p", "--all", "--no-color", "-U0", "--", "."],
                         capture_output=True, text=True, errors="replace")
    secret_rules = [(t, rx) for rid, _s, t, _e, rx, _f in COMPILED if rid == "SECRET"]
    hits, commit, fname, seen = [], "?", "?", set()
    for line in out.stdout.splitlines():
        if line.startswith("commit "):
            commit = line[7:15]
        elif line.startswith("+++ b/"):
            fname = line[6:]
        elif line.startswith("+") and not line.startswith("+++") and len(line) < 600:
            if ".claude/skills" in fname:
                continue
            for title, rx in secret_rules:
                m = rx.search(line)
                if m and not PLACEHOLDER.search(m.group(0)) and (fname, m.group(0)) not in seen:
                    seen.add((fname, m.group(0)))
                    hits.append(dict(id="SECRET-GIT", severity="critical",
                                     title=title + " (in git history)", file=fname,
                                     line=f"commit {commit}", code=line[1:].strip()[:160],
                                     fix="Rotate the secret. Deleting the line is not enough: it stays in history"))
    return hits, None


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root")
    ap.add_argument("--out", default="audit-out")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    hits = []
    for path, rel in walk_files(root):
        if rel.endswith((".md", ".txt", "package-lock.json", ".min.js", ".map")):
            continue
        hits.extend(scan_file(path, rel))
    git_hits, git_err = scan_git_history(root)
    hits.extend(git_hits or [])
    hits.sort(key=lambda h: (SEV_ORDER[h["severity"]], h["file"], str(h["line"])))

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "code_scan.json"), "w", encoding="utf-8") as fh:
        json.dump({"hits": hits, "git_history": git_err or "scanned"}, fh, indent=2)
    md = ["# Code scan (leads to confirm)", "",
          "| severity | id | file:line | what | code | fix |", "|---|---|---|---|---|---|"]
    for h in hits:
        md.append(f"| {h['severity']} | {h['id']} | {h['file']}:{h['line']} | {md_cell(h['title'])} | "
                  f"`{md_cell(h['code'])}` | {md_cell(h['fix'])} |")
    md += ["", f"Git history scan: {git_err and 'NOT VERIFIED - ' + git_err or 'done'}"]
    with open(os.path.join(args.out, "code_scan.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    print("\n".join(md))
    counts = {}
    for h in hits:
        counts[h["severity"]] = counts.get(h["severity"], 0) + 1
    print(f"\n{len(hits)} leads: {counts}")


if __name__ == "__main__":
    main()
