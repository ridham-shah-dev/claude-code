#!/usr/bin/env python3
"""Confirm SQL injection and reflected/stored XSS on ONE form or URL of your own app.

Usage:
  python probe_inputs.py --base http://localhost:5000 --path /login --method POST \
      --params username password [--fixed remember=1]
      [--login /login --user alice]   (password from env AUDIT_PASSWORD; needed for pages behind login)
      [--view /notes/5]               (page where the saved value is shown: checks stored XSS)

What it sends (harmless test values only):
  1. a normal random word          -> baseline answer
  2. a single quote  '             -> HTTP 500 / SQL error text = query is built from input
  3. x' OR '1'='1' --              -> answer differs from baseline like a "true" query = SQL injection
  4. <audit-xss-12345> marker tag  -> comes back unescaped = XSS
It never reads or changes other data on purpose, but a broken query can do odd things:
use a dev database.
"""
import argparse
import json
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import Client, md_cell, require_owned, split_cred  # noqa: E402

SQL_ERRORS = re.compile(
    r"(?i)sqlite3?\.\w*Error|OperationalError|syntax error at or near|You have an error in your SQL syntax|"
    r"SQLSTATE\[|unterminated quoted string|ORA-\d{5}|PG::SyntaxError|SequelizeDatabaseError|"
    r"mysqli?_|near \".*\": syntax error|unrecognized token|Traceback \(most recent call last\)")


def sig(r):
    return (r["status"], r["headers"].get("location", ""), len(r["body"]) // 50)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", required=True)
    ap.add_argument("--path", required=True)
    ap.add_argument("--method", default="GET")
    ap.add_argument("--params", nargs="+", required=True, help="input names to test")
    ap.add_argument("--fixed", nargs="*", default=[], help="other fields as name=value")
    ap.add_argument("--login")
    ap.add_argument("--user")
    ap.add_argument("--user-field", default="username")
    ap.add_argument("--pass-field", default="password")
    ap.add_argument("--view", help="page that shows the saved value (stored XSS)")
    ap.add_argument("--out", default="audit-out")
    ap.add_argument("--i-own-this", action="store_true")
    args = ap.parse_args()
    require_owned(args.base, args.i_own_this)

    def new_client():
        c = Client(args.base)
        if args.login and args.user:
            user, pw = split_cred(args.user, "AUDIT_PASSWORD")
            ok, _ = c.login(args.login, user, pw, args.user_field, args.pass_field)
            if not ok:
                sys.exit("Could not log in with the test user.")
        return c

    fixed = dict(f.split("=", 1) for f in args.fixed)
    method = args.method.upper()

    def send(values):
        c = new_client()  # fresh session each time so a login bypass in one test cannot leak into the next
        data = dict(fixed)
        if method != "GET":
            page = c.request(args.path, follow=True)
            data.update(c.hidden_fields(page["body"]))
        data.update(values)
        if method == "GET":
            from urllib.parse import urlencode
            r = c.request(args.path + ("&" if "?" in args.path else "?") + urlencode(data))
        else:
            r = c.request(args.path, method, data=data)
        return c, r

    rows = []
    word = "audit" + str(random.randint(10000, 99999))
    base_values = {p: word for p in args.params}
    _, baseline = send(base_values)
    _, baseline2 = send({p: word + "b" for p in args.params})
    stable = sig(baseline) == sig(baseline2)

    for p in args.params:
        # --- SQL injection
        _, rq = send(dict(base_values, **{p: word + "'"}))
        _, rt = send(dict(base_values, **{p: word + "' OR  '1'='1' -- "}))   # always true
        _, rf = send(dict(base_values, **{p: word + "' AND '1'='2' -- "}))   # always false, same length
        err = SQL_ERRORS.search(rq["body"])
        crashed = err or (rq["status"] >= 500 and baseline["status"] < 500)
        if stable and sig(rt) != sig(rf) and rt["status"] < 500:
            rows.append(dict(param=p, test="' OR '1'='1' --", verdict="FAIL: SQL injection CONFIRMED",
                             detail=f"always-true input got HTTP {rt['status']} {rt['headers'].get('location', '')}, "
                                    f"always-false input got HTTP {rf['status']}: the input changes the query"))
        elif crashed:
            rows.append(dict(param=p, test="single quote", verdict="FAIL: SQL injection likely",
                             detail=f"HTTP {rq['status']}" + (f", error text: {err.group(0)[:60]}" if err else "")))
        else:
            rows.append(dict(param=p, test="SQL injection", verdict="PASS",
                             detail="quote, always-true and always-false inputs all behave like a normal word"))
        if re.search(r"Traceback \(most recent call last\)|Werkzeug Debugger|Stack trace:|<b>Fatal error</b>", rq["body"]):
            rows.append(dict(param=p, test="error page", verdict="FAIL: error page leaks details",
                             detail="a stack trace / debugger page is shown to the user"))
        # --- XSS
        marker = f"<audit-xss-{random.randint(10000, 99999)}>"
        attr_marker = f'"audit-attr-{random.randint(10000, 99999)}='
        c, rx = send(dict(base_values, **{p: marker + attr_marker}))
        if rx["status"] in (301, 302, 303):
            rx = c.request(rx["headers"].get("location", "/"), follow=True)
        body = rx["body"]

        def html_of(resp):
            # only HTML can run scripts: a text/plain or JSON download is not XSS
            return resp["body"] if "html" in resp["headers"].get("content-type", "text/html") else ""

        places = [("answer page", html_of(rx))]
        if args.view:
            places.append((f"view page {args.view}", html_of(c.request(args.view, follow=True))))
        elif method != "GET":
            # no --view given: open a few links of the answer page (the new item is usually first or last)
            links = [h for h in dict.fromkeys(re.findall(r"""href=["'](/[^"'#]*)""", body))
                     if not re.search(r"(?i)log-?out|sign-?out|delete", h)]
            for h in links[:3] + links[-5:]:
                places.append((f"page {h}", html_of(c.request(h, follow=True))))
        hit = None
        for where, text in places:
            if marker in text:
                hit = f"tag came back unescaped in the {where}"
            elif re.search(r'=\s*"[^"<>]*' + re.escape(attr_marker), text):
                hit = f"double quote came back unescaped inside an attribute in the {where}"
            if hit:
                break
        if hit:
            rows.append(dict(param=p, test="XSS marker", verdict="FAIL: XSS CONFIRMED", detail=hit))
        else:
            rows.append(dict(param=p, test="XSS marker", verdict="PASS",
                             detail=f"marker was escaped or not shown ({len(places)} pages checked" +
                                    ("" if args.view or method == "GET" else "; give --view to check one exact page") + ")"))

    md = [f"# Input probe: {method} {args.path}", "", "| input | test | verdict | detail |", "|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['param']} | {md_cell(r['test'])} | {md_cell(r['verdict'])} | {md_cell(r['detail'])} |")
    os.makedirs(args.out, exist_ok=True)
    name = f"probe_{method}_" + (re.sub(r"\W+", "_", args.path).strip("_") or "root")
    with open(os.path.join(args.out, name + ".json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, indent=2)
    with open(os.path.join(args.out, name + ".md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
