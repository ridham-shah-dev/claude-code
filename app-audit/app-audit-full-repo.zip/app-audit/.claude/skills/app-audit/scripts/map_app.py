#!/usr/bin/env python3
"""Map an app from its source code: stack, routes, API endpoints, forms, buttons, links.

Usage: python map_app.py <app-folder> [--out audit-out]

Also flags routes that take an id but show no login or owner check in the handler.
Those are LEADS for broken access control: confirm them with access_check.py.
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import md_cell, read_text, walk_files  # noqa: E402

STACK_HINTS = [
    # (label, kind, file-name regex or None, content regex)
    ("Python", "language", r"\.py$", None),
    ("JavaScript/TypeScript", "language", r"\.(js|ts|jsx|tsx|mjs)$", None),
    ("PHP", "language", r"\.php$", None),
    ("Ruby", "language", r"\.rb$", None),
    ("Go", "language", r"\.go$", None),
    ("Java", "language", r"\.java$", None),
    ("C#", "language", r"\.cs$", None),
    ("Flask", "framework", r"\.py$|requirements.*\.txt$|pyproject\.toml$", r"\bflask\b"),
    ("Django", "framework", r"\.py$|requirements.*\.txt$", r"\bdjango\b"),
    ("FastAPI", "framework", r"\.py$|requirements.*\.txt$|pyproject\.toml$", r"\bfastapi\b"),
    ("Express", "framework", r"package\.json$|\.(js|ts)$", r"""["']express["']"""),
    ("Next.js", "framework", r"package\.json$", r'"next"\s*:'),
    ("React", "framework", r"package\.json$", r'"react"\s*:'),
    ("Vue", "framework", r"package\.json$", r'"vue"\s*:'),
    ("Laravel", "framework", r"composer\.json$", r"laravel/framework"),
    ("GraphQL", "api", r"\.(py|js|ts|json|graphql|gql)$", r"(?i)graphql|apollo-server|graphene|strawberry"),
    ("REST/JSON", "api", r"\.(py|js|ts|php)$", r"jsonify\(|res\.json\(|JsonResponse|json_encode\(|@(app|router)\.(get|post)\("),
    ("SQLite", "database", None, r"(?i)\bsqlite3?\b"),
    ("PostgreSQL", "database", None, r"(?i)postgres(ql)?://|psycopg|\bpg\b['\"]|pg_connect"),
    ("MySQL/MariaDB", "database", None, r"(?i)mysql://|mysqli|pymysql|mysql2|mysqlclient"),
    ("MongoDB", "database", None, r"(?i)mongodb(\+srv)?://|mongoose|pymongo"),
    ("Redis", "cache", None, r"(?i)\bredis\b"),
    ("Cache headers / cache lib", "cache", None, r"(?i)Cache-Control|flask_caching|lru_cache|memcache"),
    ("ORM (SQLAlchemy/Prisma/Sequelize/Eloquent)", "database", None, r"(?i)sqlalchemy|prisma|sequelize|typeorm|eloquent"),
    ("Background jobs", "jobs", None, r"(?i)\bcelery\b|\brq\b|bullmq|\bbull\b|sidekiq|apscheduler|node-cron|crontab"),
    ("Logging", "logging", None, r"(?i)\blogging\.|getLogger|winston|pino|morgan|monolog|app\.logger"),
    ("Monitoring", "monitoring", None, r"(?i)sentry|prometheus|opentelemetry|datadog|newrelic"),
    ("Password hashing", "auth", None, r"(?i)bcrypt|argon2|scrypt|pbkdf2|generate_password_hash|password_hash\("),
    ("Sessions", "auth", None, r"(?i)\bsession\[|express-session|flask_login|\$_SESSION|req\.session"),
    ("JWT", "auth", None, r"(?i)\bjwt\b|jsonwebtoken"),
    ("CSRF protection", "security", None, r"(?i)csrf"),
    ("Rate limiting", "security", None, r"(?i)flask_limiter|express-rate-limit|ratelimit|throttle"),
    ("Security headers lib", "security", None, r"(?i)helmet|talisman|Content-Security-Policy|Strict-Transport-Security"),
    ("Input validation lib", "security", None, r"(?i)pydantic|marshmallow|wtforms|\bzod\b|\bjoi\b|express-validator|validator\."),
    ("CORS config", "security", None, r"(?i)\bcors\b|Access-Control-Allow-Origin"),
    ("File uploads", "feature", None, r"request\.files|multer|\$_FILES|enctype=[\"']multipart"),
]
PRESENCE = [
    ("Migrations", r"(^|/)(migrations|alembic|prisma/migrations|db/migrate)(/|$)"),
    ("Tests", r"(^|/)(tests?|__tests__|spec)(/|$)|(^|/)test_[^/]+\.py$|\.(test|spec)\.[jt]sx?$"),
    ("CI (GitHub Actions / GitLab)", r"^\.github/workflows/.+\.ya?ml$|^\.gitlab-ci\.yml$"),
    ("Dockerfile", r"(^|/)Dockerfile$|docker-compose\.ya?ml$"),
    ("Dependency lock file", r"(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|poetry\.lock|uv\.lock|Pipfile\.lock|composer\.lock)$"),
    (".gitignore", r"^\.gitignore$"),
    (".env file present", r"(^|/)\.env$"),
    ("Backup script", r"(?i)backup|pg_dump|mysqldump"),
    ("Privacy / cookie page", r"(?i)privacy|cookie|gdpr|legal"),
    ("README", r"(?i)^readme"),
]

FLASK_ROUTE = re.compile(
    r"""^\s*@\s*(\w+)\.(route|get|post|put|patch|delete)\(\s*["']([^"']*)["']([^)]*)\)""")
EXPRESS_ROUTE = re.compile(
    r"""\b(app|router|\w*[rR]outer)\.(get|post|put|patch|delete|all)\(\s*["'`]([^"'`]+)["'`]\s*,?(.*)""")
DJANGO_ROUTE = re.compile(r"""\b(?:path|re_path|url)\(\s*r?["']([^"']*)["']\s*,\s*([\w.]+)""")
LARAVEL_ROUTE = re.compile(r"""Route::(get|post|put|patch|delete|any)\(\s*["']([^"']+)["']""")
AUTH_WORDS = re.compile(
    r"(?i)login_required|current_user|session\[|session\.get|[\"']user_id[\"'] (?:not )?in session|"
    r"req\.user|req\.session|isAuthenticated|requireAuth|authenticate|jwt_required|"
    r"Depends\(\s*get_current|permission_required|\$_SESSION|auth\(\)|@auth|verify_?[tT]oken|ensureLoggedIn")
OWNER_WORDS = re.compile(
    r"(?i)(user_id|owner_id|owner|author_id|account_id|created_by)\s*(==|=\s*\?|=\s*%s|=\s*\$\d|:\s*req\.user|=\s*:)|"
    r"(==|!=|is not|!==|===)\s*(session\[|current_user|req\.user|g\.user)|"
    r"(session\[[^\]]+\]|current_user\.id|req\.user\.id|g\.user\.id)\s*(==|!=|!==|===|\)|,)|"
    r"filter_by\([^)]*user|\.owner\b|abort\(\s*40[34]|is_admin|role\s*[!=]=|has_permission|can\(")
ADMIN_PATH = re.compile(r"(?i)/(admin|manage|internal|staff|dashboard/users)")


def py_handler_body(lines, start):
    """Return (decorators, body) for the function that follows a route decorator line."""
    i = start
    decorators = []
    while i < len(lines) and not re.match(r"\s*(async\s+)?def\s", lines[i]):
        decorators.append(lines[i])
        i += 1
    if i >= len(lines):
        return "", ""
    indent = len(lines[i]) - len(lines[i].lstrip())
    body = [lines[i]]
    i += 1
    while i < len(lines):
        ln = lines[i]
        if ln.strip() and (len(ln) - len(ln.lstrip())) <= indent:
            break
        body.append(ln)
        i += 1
    return "\n".join(decorators), "\n".join(body)


def js_handler_body(lines, start):
    """Rough handler text: from the route line until brackets balance (max 80 lines)."""
    depth, out = 0, []
    for ln in lines[start:start + 80]:
        out.append(ln)
        depth += ln.count("(") - ln.count(")")
        if depth <= 0 and len(out) > 0 and ")" in ln:
            break
    return "\n".join(out)


def find_routes(root):
    routes = []
    for path, rel in walk_files(root, exts={".py", ".js", ".ts", ".mjs", ".cjs", ".php"}):
        lines = read_text(path).splitlines()
        for i, line in enumerate(lines):
            m = FLASK_ROUTE.match(line)
            if m and rel.endswith(".py"):
                verb = m.group(2)
                methods = re.findall(r"""["'](GET|POST|PUT|PATCH|DELETE)["']""", m.group(4)) or \
                    (["GET"] if verb == "route" else [verb.upper()])
                decos, body = py_handler_body(lines, i)
                routes.append(route_info(rel, i + 1, methods, m.group(3), decos + "\n" + body))
                continue
            m = EXPRESS_ROUTE.search(line)
            if m and rel.endswith((".js", ".ts", ".mjs", ".cjs")) and m.group(3).startswith("/"):
                routes.append(route_info(rel, i + 1, [m.group(2).upper()], m.group(3),
                                         js_handler_body(lines, i)))
                continue
            m = DJANGO_ROUTE.search(line)
            if m and rel.endswith("urls.py"):
                routes.append(dict(file=rel, line=i + 1, methods=["ANY"], path="/" + m.group(1),
                                   has_id=bool(re.search(r"<|\(\?P", m.group(1))), auth="check view: " + m.group(2),
                                   owner_check="?", lead=""))
                continue
            m = LARAVEL_ROUTE.search(line)
            if m and rel.endswith(".php"):
                routes.append(route_info(rel, i + 1, [m.group(1).upper()], m.group(2), line))
    # file-based routes
    for path, rel in walk_files(root, exts={".php", ".html", ".htm", ".js", ".jsx", ".ts", ".tsx"}):
        m = re.search(r"(?:^|/)(?:src/)?(?:pages|app)/(.*?)(?:/page|/route|/index)?\.(?:jsx?|tsx?)$", rel)
        if m and not re.search(r"(^|/)_|components?/|lib/|utils?/", m.group(1)):
            kind = "API" if "/api/" in "/" + m.group(1) + "/" or rel.endswith(("route.ts", "route.js")) else "PAGE"
            txt = read_text(path)
            routes.append(route_info(rel, 1, [kind], "/" + m.group(1).replace("index", "").rstrip("/"), txt))
        elif rel.endswith(".php") and not re.search(r"(^|/)(vendor|includes?|lib|config|src|app|routes)/", rel) \
                and "<?php" in read_text(path)[:2000] and not os.path.exists(os.path.join(root, "artisan")):
            routes.append(route_info(rel, 1, ["GET/POST"], "/" + rel, read_text(path)))
        elif rel.endswith((".html", ".htm")) and not re.search(r"(^|/)templates?/|(^|/)views?/|layouts?/|partials?/", rel) \
                and "{%" not in read_text(path):
            routes.append(dict(file=rel, line=1, methods=["STATIC"], path="/" + rel, has_id=False,
                               auth="public", owner_check="n/a", lead=""))
    return routes


def route_info(rel, line, methods, path, body):
    has_id = bool(re.search(r"<[^>]*>|:\w+|\{\w+\}|\[\w+\]", path)) or \
        bool(re.search(r"""(?:args|query|GET)\W{1,4}(?:get\()?["']?\w*id\b""", body))
    has_auth = bool(AUTH_WORDS.search(body))
    owner = bool(OWNER_WORDS.search(body))
    writes = any(m in ("POST", "PUT", "PATCH", "DELETE") for m in methods)
    lead = ""
    if has_id and not owner:
        lead = "ACCESS: takes an id but no owner/role check seen (can user A open user B's item?)"
    elif ADMIN_PATH.search(path) and not owner:
        lead = "ACCESS: admin path with no role check seen"
    elif writes and not has_auth and not re.search(r"(?i)log-?in|log-?out|sign-?(?:in|up|out)|register|contact|webhook|password", path):
        lead = "ACCESS: changes data but no login check seen"
    return dict(file=rel, line=line, methods=methods, path=path, has_id=has_id,
                auth="login check seen" if has_auth else "no login check seen",
                owner_check="yes" if owner else "no", lead=lead)


TAG = re.compile(r"<(a|button|form|input|select|textarea)\b([^>]*)>(?:([^<]{0,80})(?=<))?", re.I | re.S)
ATTR = re.compile(r"""([\w:@.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|\{([^}]*)\})""")


def find_ui(root):
    items = []
    exts = {".html", ".htm", ".jinja", ".jinja2", ".j2", ".ejs", ".hbs", ".vue", ".svelte", ".twig",
            ".erb", ".php", ".jsx", ".tsx"}
    for path, rel in walk_files(root, exts=exts):
        text = read_text(path)
        for m in TAG.finditer(text):
            tag = m.group(1).lower()
            attrs = {a.group(1).lower(): (a.group(2) or a.group(3) or a.group(4) or "") for a in ATTR.finditer(m.group(2))}
            line = text.count("\n", 0, m.start()) + 1
            label = (m.group(3) or "").strip() or attrs.get("value", "") or attrs.get("aria-label", "") \
                or attrs.get("placeholder", "") or attrs.get("name", "")
            if tag == "a":
                kind, target = "link", attrs.get("href", attrs.get("to", "(no href)"))
            elif tag == "form":
                kind, target = "form", f"{attrs.get('method', 'get').upper()} {attrs.get('action', '(same page)')}"
            elif tag == "button" or attrs.get("type") in ("submit", "button", "reset"):
                handler = next((v for k, v in attrs.items() if k in ("onclick", "@click", "v-on:click", "on:click")), "")
                kind, target = "button", handler or f"type={attrs.get('type', 'submit')}" + \
                    (f" id={attrs['id']}" if "id" in attrs else "")
            else:
                kind, target = "field", f"name={attrs.get('name', '?')} type={attrs.get('type', tag)}"
            items.append(dict(file=rel, line=line, kind=kind, label=label[:60], target=target[:100]))
    return items


def find_stack(root):
    found, files = {}, []
    for path, rel in walk_files(root):
        files.append(rel)
        text = None
        for label, kind, name_rx, content_rx in STACK_HINTS:
            if (kind, label) in found:
                continue
            if name_rx and not re.search(name_rx, rel):
                continue
            if content_rx is None:
                found[(kind, label)] = rel
                continue
            if rel.endswith((".md", ".txt")) and not re.search(r"requirements", rel):
                continue
            if text is None:
                text = read_text(path)
            m = re.search(content_rx, text)
            if m:
                found[(kind, label)] = f"{rel}:{text.count(chr(10), 0, m.start()) + 1}"
    # hidden files/folders that walk_files skips or that have no extension
    extra = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ("node_modules", ".git", "venv", ".venv")]
        for n in filenames + dirnames:
            extra.append(os.path.relpath(os.path.join(dirpath, n), root).replace(os.sep, "/"))
    presence = {}
    for label, rx in PRESENCE:
        hit = next((f for f in extra if re.search(rx, f)), None)
        presence[label] = hit or "NOT FOUND"
    return found, presence


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root")
    ap.add_argument("--out", default="audit-out")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    stack, presence = find_stack(root)
    routes = find_routes(root)
    ui = find_ui(root)

    md = ["# App map", "", "## Stack (found in code)", "", "| area | what | where |", "|---|---|---|"]
    for (kind, label), where in sorted(stack.items()):
        md.append(f"| {kind} | {label} | {where} |")
    kinds = {k for k, _ in stack}
    for needed in ("framework", "api", "database", "cache", "jobs", "logging", "monitoring", "auth", "security"):
        if needed not in kinds:
            md.append(f"| {needed} | NOT FOUND in code | - |")
    md += ["", "## Project hygiene", "", "| item | where |", "|---|---|"]
    md += [f"| {k} | {v} |" for k, v in presence.items()]
    md += ["", "## Routes and API endpoints", "",
           "| methods | path | file:line | login | owner check | lead |", "|---|---|---|---|---|---|"]
    for r in routes:
        md.append(f"| {','.join(r['methods'])} | `{md_cell(r['path'])}` | {r['file']}:{r['line']} | {r['auth']} | "
                  f"{r['owner_check']} | {md_cell(r['lead'])} |")
    md += ["", "## Pages: links, buttons, forms, fields", "",
           "| file:line | kind | label | target |", "|---|---|---|---|"]
    for u in ui:
        md.append(f"| {u['file']}:{u['line']} | {u['kind']} | {md_cell(u['label'])} | `{md_cell(u['target'])}` |")
    # links in templates that point to no known route
    known = [re.sub(r"<[^>]*>|:\w+|\{\w+\}|\[\w+\]", "[^/]+", r["path"]).rstrip("/") or "/" for r in routes]
    orphans = []
    for u in ui:
        if u["kind"] != "link":
            continue
        href = u["target"].split("?")[0].split("#")[0]
        if not href.startswith("/") or "{" in href or href.startswith("//") or href.startswith("/static"):
            continue
        if routes and not any(re.fullmatch(k, href.rstrip("/") or "/") for k in known):
            orphans.append(u)
    md += ["", "## Links with no matching route (possible dead links)", ""]
    md += [f"- {u['file']}:{u['line']} -> `{u['target']}` ({u['label']})" for u in orphans] or ["- none found"]
    leads = [r for r in routes if r["lead"]]
    md += ["", "## Access-control leads (confirm with access_check.py)", ""]
    md += [f"- {r['file']}:{r['line']} `{r['path']}` - {r['lead']}" for r in leads] or ["- none found"]

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "map.json"), "w", encoding="utf-8") as fh:
        json.dump(dict(stack={f"{k}:{v}": w for (k, v), w in stack.items()}, presence=presence,
                       routes=routes, ui=ui, orphan_links=orphans), fh, indent=2)
    with open(os.path.join(args.out, "MAP.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
