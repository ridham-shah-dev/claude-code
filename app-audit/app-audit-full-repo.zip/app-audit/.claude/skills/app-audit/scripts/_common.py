"""Shared helpers for the app-audit scripts (standard library only)."""
import ipaddress
import os
import sys
from urllib.parse import urlparse

SKIP_DIRS = {
    ".git", "node_modules", "venv", ".venv", "env", "__pycache__", "dist", "build",
    ".next", ".nuxt", "vendor", ".idea", ".vscode", "coverage", ".pytest_cache",
    ".mypy_cache", "target", "bin", "obj", ".claude", "audit-out",
}
TEXT_EXT = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".php", ".rb", ".go", ".java",
    ".cs", ".html", ".htm", ".jinja", ".jinja2", ".j2", ".ejs", ".hbs", ".vue", ".svelte",
    ".twig", ".erb", ".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".conf", ".env",
    ".sh", ".sql", ".xml", ".txt", ".md",
}


def walk_files(root, exts=None, max_bytes=1_000_000):
    """Yield (path, relative_path) for source files, skipping vendored folders."""
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            ext = os.path.splitext(name)[1].lower()
            is_env = name == ".env" or name.startswith(".env.")
            if not is_env and ext not in (exts or TEXT_EXT):
                continue
            path = os.path.join(dirpath, name)
            try:
                if os.path.getsize(path) > max_bytes:
                    continue
            except OSError:
                continue
            yield path, os.path.relpath(path, root).replace(os.sep, "/")


def read_text(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return ""


def is_local(url):
    host = (urlparse(url).hostname or "").lower()
    if host in ("localhost",) or host.endswith(".localhost") or host.endswith(".test"):
        return True
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_loopback or ip.is_private
    except ValueError:
        return False


def require_owned(url, i_own_this):
    """These scripts send test requests. Only allow local apps unless the owner confirms."""
    if is_local(url) or i_own_this:
        return
    sys.exit(
        f"STOP: {url} is not a local address.\n"
        "This tool is for apps you own. If this is your own site, run again with --i-own-this."
    )


def md_cell(value):
    return str(value).replace("|", "\\|").replace("\n", " ").strip()


# ------------------------------------------------------------------ small HTTP client
import http.cookiejar  # noqa: E402
import re  # noqa: E402
import urllib.error  # noqa: E402
import urllib.parse  # noqa: E402
import urllib.request  # noqa: E402


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class Client:
    """One browser-like user: keeps cookies, does not follow redirects unless asked."""

    def __init__(self, base):
        self.base = base.rstrip("/")
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar), _NoRedirect)

    def request(self, path, method="GET", data=None, headers=None, follow=False, json_body=None):
        url = path if path.startswith("http") else self.base + "/" + path.lstrip("/")
        body = None
        hdrs = {"User-Agent": "app-audit/1.0"}
        if json_body is not None:
            import json as _json
            body = _json.dumps(json_body).encode()
            hdrs["Content-Type"] = "application/json"
        elif data is not None:
            body = urllib.parse.urlencode(data).encode()
        hdrs.update(headers or {})
        for _ in range(6):
            req = urllib.request.Request(url, data=body, method=method, headers=hdrs)
            try:
                resp = self.opener.open(req, timeout=10)
            except urllib.error.HTTPError as e:
                resp = e
            except (urllib.error.URLError, OSError) as e:
                return dict(status=0, headers={}, raw_headers=[], body=f"connection error: {e}", url=url)
            text = resp.read(2_000_000).decode("utf-8", "replace")
            status = resp.status if hasattr(resp, "status") else resp.code
            out = dict(status=status, headers={k.lower(): v for k, v in resp.headers.items()},
                       raw_headers=list(resp.headers.items()), body=text, url=url)
            if follow and status in (301, 302, 303, 307, 308) and "location" in out["headers"]:
                url = urllib.parse.urljoin(url, out["headers"]["location"])
                if status != 307 and status != 308:
                    method, body = "GET", None
                continue
            return out
        return out

    def hidden_fields(self, html, action_hint=""):
        """Hidden inputs of the form (picks up CSRF tokens)."""
        fields = {}
        for m in re.finditer(r"<input\b[^>]*>", html, re.I):
            tag = m.group(0)
            if re.search(r"""type\s*=\s*["']?hidden""", tag, re.I):
                n = re.search(r"""name\s*=\s*["']([^"']+)""", tag)
                v = re.search(r"""value\s*=\s*["']([^"']*)""", tag)
                if n:
                    fields[n.group(1)] = v.group(1) if v else ""
        return fields

    def login(self, login_path, username, password, user_field="username", pass_field="password"):
        page = self.request(login_path, follow=True)
        data = self.hidden_fields(page["body"])
        data.update({user_field: username, pass_field: password})
        r = self.request(login_path, "POST", data=data)
        ok = r["status"] in (301, 302, 303) or (r["status"] == 200 and "type=\"password\"" not in r["body"]
                                                and "type='password'" not in r["body"])
        return ok, r


def split_cred(text, env_name):
    """'alice' + password from env, or 'alice:password'. Passwords are never printed."""
    import os as _os
    if ":" in text:
        user, pw = text.split(":", 1)
        return user, pw
    pw = _os.environ.get(env_name)
    if not pw:
        sys.exit(f"Give the test password as user:password or set {env_name}.")
    return text, pw
