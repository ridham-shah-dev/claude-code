#!/usr/bin/env python3
"""Broken access control test: can user B (or nobody) open user A's things?

Usage:
  python access_check.py --base http://localhost:5000 --login /login \
      --user-a alice --user-b bob  (passwords from env AUDIT_PASSWORD_A / AUDIT_PASSWORD_B,
                                    or write alice:pw)
      --paths /notes/1 /api/orders/7 /admin
      [--user-field username --pass-field password] [--method GET]

--paths = URLs that belong to user A only (or to admins only).
For each path it asks three times: as A (owner), as B (other user), as nobody.
FAIL = B or nobody gets the same content as A.
"""
import argparse
import difflib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import Client, md_cell, require_owned, split_cred  # noqa: E402


def same_content(a, b):
    if a["status"] != b["status"]:
        return False
    if a["body"] == b["body"]:
        return True
    return difflib.SequenceMatcher(None, a["body"][:20000], b["body"][:20000]).quick_ratio() > 0.9


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", required=True)
    ap.add_argument("--login", required=True)
    ap.add_argument("--user-a", required=True)
    ap.add_argument("--user-b", required=True)
    ap.add_argument("--paths", nargs="+", required=True)
    ap.add_argument("--user-field", default="username")
    ap.add_argument("--pass-field", default="password")
    ap.add_argument("--method", default="GET", help="GET by default. For POST/PUT/DELETE test by hand with care")
    ap.add_argument("--out", default="audit-out")
    ap.add_argument("--i-own-this", action="store_true")
    args = ap.parse_args()
    require_owned(args.base, args.i_own_this)

    ua, pa = split_cred(args.user_a, "AUDIT_PASSWORD_A")
    ub, pb = split_cred(args.user_b, "AUDIT_PASSWORD_B")
    a, b, anon = Client(args.base), Client(args.base), Client(args.base)
    for name, client, user, pw in (("A", a, ua, pa), ("B", b, ub, pb)):
        ok, _ = client.login(args.login, user, pw, args.user_field, args.pass_field)
        if not ok:
            sys.exit(f"Could not log in as user {name} ({user}). Check the login path, field names and test password.")

    rows = []
    for path in args.paths:
        ra = a.request(path, args.method)
        rb = b.request(path, args.method)
        rn = anon.request(path, args.method)
        if ra["status"] != 200:
            verdict = f"NOT VERIFIED: owner A got HTTP {ra['status']} (wrong path?)"
        else:
            problems = []
            if same_content(ra, rb):
                problems.append(f"user B ({ub}) sees user A's data")
            if same_content(ra, rn):
                problems.append("nobody (not logged in) sees user A's data")
            if problems:
                verdict = "FAIL: " + "; ".join(problems)
            elif rb["status"] == 200:
                verdict = "CHECK BY HAND: user B gets HTTP 200 with different content (fine if it is B's own data)"
            else:
                verdict = "PASS"
        rows.append(dict(path=path, a=ra["status"], b=rb["status"], anon=rn["status"], verdict=verdict))

    md = ["# Access control test", "", f"Owner = {ua}, other user = {ub}", "",
          "| path | owner A | user B | not logged in | verdict |", "|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| `{md_cell(r['path'])}` | {r['a']} | {r['b']} | {r['anon']} | {md_cell(r['verdict'])} |")
    md += ["", "Only the paths you listed were tested. Write/delete actions were not tested by this script."]
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "access_check.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, indent=2)
    with open(os.path.join(args.out, "access_check.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
