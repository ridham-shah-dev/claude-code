#!/usr/bin/env python3
"""Check what the running app sends over HTTP: security headers, cookies, CORS,
error leaks, cache headers, and (optional) login rate limiting.

Usage:
  python check_http.py --base http://localhost:5000 [--paths / /login]
      [--login /login --user alice]      (password from env AUDIT_PASSWORD) -> checks the session cookie
      [--lockout-test 12]                -> sends 12 wrong passwords to see if the app slows or blocks
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import Client, is_local, md_cell, require_owned, split_cred  # noqa: E402

LEAK = re.compile(
    r"Traceback \(most recent call last\)|Werkzeug Debugger|werkzeug\.exceptions|at \w[\w.$<>]* \(.+:\d+:\d+\)|"
    r"<b>(?:Fatal error|Warning|Notice)</b>:|SQLSTATE\[|sqlite3\.\w+Error|Stack trace:|"
    r"DEBUG = True|Whoops, looks like something went wrong|django\.core|in /(?:var|home|usr)/\S+\.php")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", required=True)
    ap.add_argument("--paths", nargs="*", default=["/"])
    ap.add_argument("--login")
    ap.add_argument("--user")
    ap.add_argument("--user-field", default="username")
    ap.add_argument("--pass-field", default="password")
    ap.add_argument("--lockout-test", type=int, default=0)
    ap.add_argument("--out", default="audit-out")
    ap.add_argument("--i-own-this", action="store_true")
    args = ap.parse_args()
    require_owned(args.base, args.i_own_this)
    https = args.base.startswith("https://")
    local = is_local(args.base)
    rows = []

    def add(area, check, result, verdict, sev="medium"):
        rows.append(dict(area=area, check=check, result=result, verdict=verdict,
                         severity=sev if verdict == "FAIL" else "-"))

    c = Client(args.base)
    for path in args.paths:
        r = c.request(path, follow=True)
        if r["status"] == 0:
            sys.exit(f"Cannot reach {args.base}{path}: {r['body']}")
        h = r["headers"]
        csp = h.get("content-security-policy", "")
        add("headers", f"{path} Content-Security-Policy", csp[:80] or "missing", "PASS" if csp else "FAIL")
        if csp and re.search(r"script-src[^;]*'unsafe-inline'|script-src[^;]*\*(?:\s|;|$)|default-src[^;]*\*(?:\s|;|$)", csp):
            add("headers", f"{path} CSP strength", "allows unsafe-inline or * for scripts", "FAIL", "low")
        add("headers", f"{path} X-Content-Type-Options", h.get("x-content-type-options", "missing"),
            "PASS" if h.get("x-content-type-options", "").lower() == "nosniff" else "FAIL", "low")
        framed = "x-frame-options" in h or "frame-ancestors" in csp
        add("headers", f"{path} clickjacking (X-Frame-Options or CSP frame-ancestors)",
            h.get("x-frame-options", "frame-ancestors" if framed else "missing"), "PASS" if framed else "FAIL")
        add("headers", f"{path} Referrer-Policy", h.get("referrer-policy", "missing"),
            "PASS" if "referrer-policy" in h else "FAIL", "low")
        add("headers", f"{path} Permissions-Policy", h.get("permissions-policy", "missing")[:60],
            "PASS" if "permissions-policy" in h else "FAIL", "low")
        if https:
            hsts = h.get("strict-transport-security", "")
            add("headers", f"{path} HSTS", hsts or "missing", "PASS" if "max-age" in hsts else "FAIL")
        else:
            add("headers", f"{path} HSTS + HTTPS", "site tested over plain http" + (" (local)" if local else ""),
                "NOT VERIFIED" if local else "FAIL", "high")
        for name in ("server", "x-powered-by"):
            if name in h and re.search(r"\d", h[name]):
                add("leak", f"{path} {name} header shows a version", h[name], "FAIL", "low")
        cc = h.get("cache-control", "")
        add("cache", f"{path} Cache-Control", cc or "missing (browser decides)", "INFO")

    # --- error handling
    r404 = c.request("/audit-no-such-page-xyz")
    add("errors", "unknown page", f"HTTP {r404['status']}", "PASS" if r404["status"] == 404 else "CHECK", "low")
    for label, path in (("unknown page", "/audit-no-such-page-xyz"), ("quote in URL", args.paths[0].rstrip("/") + "/'%22%3E?id='&q='")):
        r = c.request(path)
        m = LEAK.search(r["body"])
        add("errors", f"error page leaks details ({label})", f"HTTP {r['status']}" + (f": {m.group(0)[:50]}" if m else ", clean"),
            "FAIL" if m else "PASS", "high")

    # --- CORS
    evil = "https://evil.example"
    r = c.request(args.paths[0], headers={"Origin": evil})
    acao = r["headers"].get("access-control-allow-origin", "")
    creds = r["headers"].get("access-control-allow-credentials", "").lower() == "true"
    if acao == evil:
        add("cors", "reflects any Origin", f"ACAO={acao} credentials={creds}", "FAIL", "high" if creds else "medium")
    elif acao == "*":
        add("cors", "allows every origin (*)", "fine for public data only; never with cookies/tokens", "CHECK")
    else:
        add("cors", "does not trust unknown origins", acao or "no CORS headers", "PASS")

    # --- TRACE / methods
    r = c.request(args.paths[0], "TRACE")
    add("methods", "TRACE method switched off", f"HTTP {r['status']}", "PASS" if r["status"] in (400, 403, 404, 405, 501) else "FAIL", "low")

    # --- session cookie
    if args.login and args.user:
        user, pw = split_cred(args.user, "AUDIT_PASSWORD")
        lc = Client(args.base)
        pre = lc.request(args.login, follow=True)
        before = {ck.name: ck.value for ck in lc.jar}
        ok, lr = lc.login(args.login, user, pw, args.user_field, args.pass_field)
        if not ok:
            add("cookies", "login with test user", "login failed", "NOT VERIFIED")
        set_cookies = [v for k, v in lr["raw_headers"] if k.lower() == "set-cookie"]
        if ok and not set_cookies:
            add("cookies", "session cookie after login", "no Set-Cookie seen (token auth?)", "NOT VERIFIED")
        for sc in set_cookies:
            name = sc.split("=", 1)[0]
            low = sc.lower()
            add("cookies", f"{name}: HttpOnly", "set" if "httponly" in low else "missing", "PASS" if "httponly" in low else "FAIL", "medium")
            add("cookies", f"{name}: SameSite", (re.search(r"samesite=(\w+)", low) or [None, "missing"])[1],
                "PASS" if re.search(r"samesite=(lax|strict)", low) else "FAIL", "medium")
            if https or not local:
                add("cookies", f"{name}: Secure", "set" if "; secure" in low else "missing", "PASS" if "; secure" in low else "FAIL", "medium")
            else:
                add("cookies", f"{name}: Secure", "set" if "; secure" in low else "missing (tested on local http)",
                    "PASS" if "; secure" in low else "NOT VERIFIED")
            value = sc.split("=", 1)[1].split(";", 1)[0]
            if name in before and before[name] == value:
                add("cookies", f"{name}: new session id after login", "same value before and after login", "FAIL", "medium")
        if ok:
            pre_has_pw_autocomplete = re.search(r"""type=["']password["'][^>]*autocomplete=["'](?:current|new)-password""", pre["body"])
            add("login", "password field has autocomplete=current-password", "yes" if pre_has_pw_autocomplete else "no",
                "PASS" if pre_has_pw_autocomplete else "INFO")

    # --- lockout / rate limit
    if args.lockout_test and args.login and args.user:
        user, _ = split_cred(args.user, "AUDIT_PASSWORD")
        lc = Client(args.base)
        codes, blocked_at = [], None
        for i in range(args.lockout_test):
            page = lc.request(args.login, follow=True)
            data = lc.hidden_fields(page["body"])
            data.update({args.user_field: user, args.pass_field: f"wrong-audit-{i}"})
            r = lc.request(args.login, "POST", data=data)
            codes.append(r["status"])
            if r["status"] in (429, 423, 403) or re.search(r"(?i)too many|locked|try again (in|later)|rate limit", r["body"]):
                blocked_at = i + 1
                break
        add("auth", f"login rate limit / lockout ({args.lockout_test} wrong passwords)",
            f"blocked after {blocked_at} tries" if blocked_at else f"never blocked (codes: {sorted(set(codes))})",
            "PASS" if blocked_at else "FAIL", "high")
        if blocked_at:
            add("auth", "NOTE", f"user '{user}' may now be locked for some minutes: restart the app or wait", "INFO")
    else:
        add("auth", "login rate limit / lockout", "not run (use --lockout-test 12 with --login and --user)", "NOT VERIFIED")

    md = ["# HTTP checks", "", f"Base: {args.base}", "", "| area | check | result | verdict | severity |", "|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['area']} | {md_cell(r['check'])} | {md_cell(r['result'])} | {r['verdict']} | {r['severity']} |")
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "http_checks.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, indent=2)
    with open(os.path.join(args.out, "http_checks.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
