#!/usr/bin/env python3
"""Open the running app in a real browser and click everything, on desktop and phone size.

Usage:
  python click_audit.py --base http://localhost:5000 [--out audit-out]
      [--login-url /login --username alice --password-env AUDIT_PASSWORD]
      [--start /extra/page ...] [--max-pages 40] [--skip "log ?out|delete"]

Needs: pip install playwright && python -m playwright install chromium

Finds: buttons that do nothing, duplicate buttons, dead links, broken forms,
console errors, failed requests, sideways scroll on phone, basic accessibility
problems, slow pages. Writes the table screen | element | expected | result | fixed?

It CLICKS AND SUBMITS for real. Run it against a dev copy with test data only.
"""
import argparse
import json
import os
import re
import sys
import time
from urllib.parse import urldefrag, urljoin, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import md_cell, require_owned  # noqa: E402

VIEWPORTS = {"desktop-1440": {"width": 1440, "height": 900}, "phone-390": {"width": 390, "height": 844}}
BUTTON_SEL = ("button, input[type=submit], input[type=button], input[type=reset], [role=button], "
              "a[href='#'], a[href=''], a:not([href]), a[href^='javascript:'], [onclick]:not(a[href]):not(button)")

OBSERVE_JS = """
() => {
  window.__audit = {mut: 0, dialogs: 0};
  new MutationObserver(l => { window.__audit.mut += l.length; })
    .observe(document.documentElement, {subtree: true, childList: true, attributes: true, characterData: true});
}
"""
DESCRIBE_JS = """
(el) => {
  const form = el.form || el.closest('form');
  const forms = Array.from(document.forms);
  const text = (el.innerText || el.value || el.getAttribute('aria-label') || el.title || '').trim().slice(0, 60);
  const r = el.getBoundingClientRect();
  const type = (el.getAttribute('type') || (el.tagName === 'BUTTON' ? 'submit' : '')).toLowerCase();
  return {
    tag: el.tagName.toLowerCase(), text, id: el.id || '', type,
    name: el.getAttribute('name') || '', value: el.getAttribute('value') || '',
    onclick: el.getAttribute('onclick') || '', href: el.getAttribute('href'),
    formIndex: form ? forms.indexOf(form) : -1,
    formAction: el.getAttribute('formaction') || (form ? (form.getAttribute('action') || '') : ''),
    formMethod: form ? (form.getAttribute('method') || 'get').toLowerCase() : '',
    disabled: !!el.disabled, visible: r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden',
    w: Math.round(r.width), h: Math.round(r.height),
  };
}
"""
FILL_JS = """
(el) => {
  const form = el.form || el.closest('form');
  if (!form) return;
  for (const f of form.elements) {
    if (f.disabled || f.readOnly) continue;
    const t = (f.type || '').toLowerCase();
    if (['submit', 'button', 'reset', 'hidden', 'file', 'image'].includes(t)) continue;
    if (t === 'checkbox' || t === 'radio') { if (f.required) f.checked = true; continue; }
    if (f.tagName === 'SELECT') { if (f.options.length > 1 && !f.value) f.selectedIndex = 1; continue; }
    if (f.value) continue;
    const v = t === 'email' ? 'audit@example.com' : t === 'number' || t === 'range' ? (f.min || '1')
      : t === 'url' ? 'https://example.com' : t === 'tel' ? '600000000' : t === 'date' ? '2025-01-15'
      : t === 'password' ? 'Audit-test-1!' : t === 'time' ? '10:00' : t === 'color' ? '#336699' : 'audit test';
    f.value = v;
    f.dispatchEvent(new Event('input', {bubbles: true}));
    f.dispatchEvent(new Event('change', {bubbles: true}));
  }
}
"""
PAGE_CHECK_JS = """
() => {
  const out = [];
  const de = document.documentElement;
  if (de.scrollWidth > window.innerWidth + 4)
    out.push(['layout', 'page', 'fits the screen width', 'sideways scroll: page is ' + de.scrollWidth + 'px wide, screen is ' + window.innerWidth + 'px']);
  if (!de.getAttribute('lang')) out.push(['a11y', '<html>', 'has a lang attribute', 'missing lang']);
  if (!document.title.trim()) out.push(['a11y', '<title>', 'page has a title', 'empty title']);
  if (!document.querySelector('meta[name=viewport]')) out.push(['layout', '<meta viewport>', 'present for phones', 'missing']);
  if (document.querySelectorAll('h1').length === 0) out.push(['a11y', '<h1>', 'one main heading', 'no h1']);
  document.querySelectorAll('img:not([alt])').forEach(i => out.push(['a11y', 'img ' + (i.getAttribute('src') || '').slice(0, 50), 'has alt text', 'missing alt']));
  document.querySelectorAll('img').forEach(i => { if (i.complete && i.naturalWidth === 0 && i.getAttribute('src')) out.push(['broken', 'img ' + i.getAttribute('src').slice(0, 50), 'image loads', 'broken image']); });
  document.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]), select, textarea').forEach(f => {
    const labelled = (f.id && document.querySelector('label[for="' + CSS.escape(f.id) + '"]')) || f.closest('label') || f.getAttribute('aria-label') || f.getAttribute('aria-labelledby') || f.title;
    if (!labelled) out.push(['a11y', 'field ' + (f.name || f.id || f.type), 'has a label', 'no <label> / aria-label (placeholder is not a label)']);
  });
  document.querySelectorAll('button, a[href], [role=button]').forEach(b => {
    const name = (b.innerText || b.getAttribute('aria-label') || b.title || '').trim() || (b.querySelector('img[alt]') || {}).alt;
    if (!name) out.push(['a11y', b.tagName.toLowerCase() + (b.id ? '#' + b.id : ''), 'has a readable name', 'no text or aria-label']);
  });
  if (window.innerWidth < 500) document.querySelectorAll('button, input[type=submit], nav a').forEach(b => {
    const r = b.getBoundingClientRect();
    if (r.width > 0 && r.height > 0 && r.height < 24) out.push(['a11y', 'tap target "' + (b.innerText || b.value || '').trim().slice(0, 30) + '"', 'at least 24px tall on phone (WCAG 2.5.8)', Math.round(r.height) + 'px tall']);
  });
  document.querySelectorAll('input[type=password]').forEach(p => {
    const f = p.form; if (f && (f.getAttribute('method') || 'get').toLowerCase() === 'get') out.push(['security', 'password form', 'uses POST', 'password form uses GET (password ends up in the URL)']);
  });
  document.querySelectorAll('form').forEach(f => {
    if ((f.getAttribute('method') || 'get').toLowerCase() === 'post' && !f.querySelector('input[type=hidden][name*=csrf i], input[type=hidden][name*=token i], input[type=hidden][name=_token]'))
      out.push(['security', 'form POST ' + (f.getAttribute('action') || '(same page)'), 'has a hidden CSRF token field', 'no CSRF token field seen']);
  });
  const nav = performance.getEntriesByType('navigation')[0];
  const res = performance.getEntriesByType('resource');
  const bytes = res.reduce((a, r) => a + (r.transferSize || 0), nav ? nav.transferSize || 0 : 0);
  return {issues: out, loadMs: nav ? Math.round(nav.loadEventEnd || nav.domContentLoadedEventEnd) : null, requests: res.length + 1, bytes};
}
"""


class Audit:
    def __init__(self, args):
        self.a = args
        self.base = args.base.rstrip("/")
        self.host = urlparse(self.base).netloc
        self.rows = []      # table rows
        self.skip = re.compile(args.skip, re.I) if args.skip else None
        self.link_status = {}
        self.downloads = set()
        self.pages = {}

    def row(self, vp, screen, element, expected, result, status):
        self.rows.append(dict(viewport=vp, screen=screen, element=element, expected=expected,
                              result=result, status=status, fixed=""))

    def same_site(self, url):
        return urlparse(url).netloc == self.host

    def path(self, url):
        u = urlparse(url)
        return (u.path or "/") + ("?" + u.query if u.query else "")

    # ---------------------------------------------------------------- login
    def login(self, page, vp):
        a = self.a
        if not a.login_url:
            return
        page.goto(urljoin(self.base + "/", a.login_url), wait_until="load")
        password = os.environ.get(a.password_env, "")
        if not password:
            sys.exit(f"Set the test password in the {a.password_env} environment variable first.")
        user = page.locator(a.user_field).first
        pw = page.locator(a.pass_field).first
        user.fill(a.username)
        pw.fill(password)
        with page.expect_navigation(wait_until="load", timeout=8000):
            pw.press("Enter")
        ok = page.locator("input[type=password]").count() == 0
        self.row(vp, a.login_url, "login form", "test user can log in",
                 "logged in" if ok else "login FAILED: still on a password form", "ok" if ok else "BUG")

    # ---------------------------------------------------------------- crawl
    def run_viewport(self, browser, vp, size):
        ctx = browser.new_context(viewport=size, is_mobile=size["width"] < 500, has_touch=size["width"] < 500)
        ctx.set_default_timeout(6000)
        page = ctx.new_page()
        console, failed = [], []
        page.on("console", lambda m: console.append((page.url, m.text)) if m.type == "error" else None)
        page.on("pageerror", lambda e: console.append((page.url, "JS error: " + str(e))))
        page.on("response", lambda r: failed.append((page.url, r.request.method, r.url, r.status)) if r.status >= 400 else None)
        page.on("requestfailed", lambda r: failed.append((page.url, r.method, r.url, "failed"))
                if "ERR_ABORTED" not in (r.failure or "") else None)  # aborted = download or page change, not a bug
        page.on("dialog", lambda d: d.dismiss())
        self.login(page, vp)

        queue = ["/"] + list(self.a.start)
        seen = set()
        while queue and len(seen) < self.a.max_pages:
            p = queue.pop(0)
            if p in seen:
                continue
            seen.add(p)
            url = urljoin(self.base + "/", p.lstrip("/")) if p != "/" else self.base + "/"
            try:
                resp = page.goto(url, wait_until="load")
            except Exception as e:  # noqa: BLE001
                if "Download is starting" in str(e):
                    self.row(vp, p, "page", "page opens", "starts a file download", "info")
                else:
                    self.row(vp, p, "page", "page opens", f"could not open: {str(e)[:80]}", "BUG")
                continue
            status = resp.status if resp else 0
            if status >= 400:
                self.row(vp, p, "page", "page opens (HTTP 200)", f"HTTP {status}", "BUG")
                continue
            landed = self.path(page.url)
            if landed != p:
                self.row(vp, p, "page", "page opens", f"redirects to {landed}", "info")
            page.wait_for_timeout(200)
            self.check_page(page, vp, p)
            for href in self.check_links(page, ctx, vp, p):
                if href not in seen and href not in queue:
                    queue.append(href)
            for href in self.check_buttons(page, ctx, vp, p, url):
                if href not in seen and href not in queue:
                    queue.append(href)
        if queue:
            self.row(vp, "(crawl)", "page limit", "all pages visited",
                     f"stopped at --max-pages {self.a.max_pages}; {len(queue)} pages NOT visited", "NOT VERIFIED")
        for where, text in dict.fromkeys(console):
            self.row(vp, self.path(where), "browser console", "no errors", text[:200], "BUG")
        for where, method, rurl, st in dict.fromkeys(failed):
            self.row(vp, self.path(where), f"request {method} {self.path(rurl) if self.same_site(rurl) else rurl[:80]}",
                     "request succeeds", f"HTTP {st}", "BUG")
        ctx.close()

    def check_page(self, page, vp, p):
        info = page.evaluate(PAGE_CHECK_JS)
        self.pages[(vp, p)] = dict(load_ms=info["loadMs"], requests=info["requests"], bytes=info["bytes"])
        for kind, element, expected, result in info["issues"]:
            self.row(vp, p, element, expected, result, "BUG" if kind in ("broken", "layout", "security") else "a11y")
        if info["loadMs"] and info["loadMs"] > 3000:
            self.row(vp, p, "page speed", "loads in under 3 s", f"{info['loadMs']} ms", "slow")
        if info["bytes"] > 3_000_000:
            self.row(vp, p, "page weight", "under 3 MB", f"{info['bytes'] // 1024} KB", "slow")

    def check_links(self, page, ctx, vp, p):
        links = page.eval_on_selector_all(
            "a[href]", "els => els.map(a => ({raw: a.getAttribute('href'), href: a.href, text: (a.innerText || a.getAttribute('aria-label') || '').trim().slice(0, 50)}))")
        next_pages = []
        for l in links:
            raw, text = l["raw"].strip(), l["text"]
            name = f'link "{text}" -> {raw[:60]}'
            if raw in ("", "#") or raw.lower().startswith("javascript:"):
                continue  # tested as a button
            if raw.startswith(("mailto:", "tel:")):
                continue
            href, frag = urldefrag(l["href"])
            if not self.same_site(href):
                if self.a.check_external:
                    st = self.fetch_status(ctx, href)
                    self.row(vp, p, name, "external link works", f"HTTP {st}", "ok" if st and st < 400 else "BUG")
                else:
                    self.row(vp, p, name, "external link works", "not checked (use --check-external)", "NOT VERIFIED")
                continue
            if frag and self.path(href) == self.path(page.url):
                exists = page.evaluate("id => !!(document.getElementById(id) || document.getElementsByName(id).length)", frag)
                self.row(vp, p, name, "jumps to a section", "target found" if exists else f"no element with id '{frag}'",
                         "ok" if exists else "BUG")
                continue
            rel = self.path(href)
            if self.skip and (self.skip.search(text) or self.skip.search(rel)):
                self.row(vp, p, name, "works", "skipped by --skip (test by hand)", "NOT VERIFIED")
                continue
            st = self.fetch_status(ctx, href)
            ok = st is not None and st < 400
            is_file = href in self.downloads
            self.row(vp, p, name, "opens a page" if not is_file else "gives a file",
                     (f"HTTP {st}" + (" (file download)" if is_file else "")) if st else "no answer",
                     "ok" if ok else "BUG (dead link)")
            if ok and not is_file and not re.search(r"\.(pdf|zip|png|jpe?g|gif|svg|css|js|ico|csv|xlsx?|docx?)$", urlparse(href).path, re.I):
                next_pages.append(rel)
        return next_pages

    def fetch_status(self, ctx, url):
        if url not in self.link_status:
            try:
                r = ctx.request.get(url, timeout=8000)
                self.link_status[url] = r.status
                ctype = r.headers.get("content-type", "")
                if "attachment" in r.headers.get("content-disposition", "") or (ctype and "html" not in ctype):
                    self.downloads.add(url)  # a file, not a page: do not open it in the crawler
            except Exception:  # noqa: BLE001
                self.link_status[url] = None
        return self.link_status[url]

    def check_buttons(self, page, ctx, vp, p, url):
        found = []
        try:
            descs = [el.evaluate(DESCRIBE_JS) for el in page.locator(BUTTON_SEL).all()]
        except Exception:  # noqa: BLE001
            descs = []
        effects = []
        for idx, d in enumerate(descs):
            label = d["text"] or d["value"] or d["id"] or d["name"] or f"#{idx}"
            name = f'{d["tag"]} "{label}"'
            if not d["visible"]:
                self.row(vp, p, name, "visible and clickable", "hidden at this screen size (check it is meant to be)", "check")
                effects.append(None)
                continue
            if d["disabled"]:
                self.row(vp, p, name, "clickable", "disabled", "info")
                effects.append(None)
                continue
            if self.skip and self.skip.search(label):
                self.row(vp, p, name, "works", "skipped by --skip (test by hand)", "NOT VERIFIED")
                effects.append(None)
                continue
            # fresh page for every click so one click cannot hide the next result
            try:
                page.goto(url, wait_until="load")
                page.evaluate(OBSERVE_JS)
                el = page.locator(BUTTON_SEL).nth(idx)
                reqs, popups, downloads, dialogs = [], [], [], []
                on_req = lambda r: reqs.append((r.method, r.url, r.resource_type))  # noqa: E731
                on_dialog = lambda dlg: dialogs.append(dlg.message)  # noqa: E731
                page.on("request", on_req)
                page.on("dialog", on_dialog)
                on_popup = lambda pg: popups.append(pg)  # noqa: E731
                on_download = lambda dl: downloads.append(dl)  # noqa: E731
                ctx.on("page", on_popup)
                page.on("download", on_download)
                in_form = d["formIndex"] >= 0 and d["type"] in ("submit", "image", "")
                if in_form:
                    el.evaluate(FILL_JS)
                    page.evaluate("() => { window.__audit.mut = 0; }")
                before = page.url
                resp_status = []
                on_resp = lambda r: resp_status.append((r.request.method, r.url, r.status)) if r.request.resource_type in ("document", "xhr", "fetch") else None  # noqa: E731
                page.on("response", on_resp)
                el.click(timeout=4000)
                page.wait_for_timeout(self.a.wait_ms)
                try:
                    page.wait_for_load_state("load", timeout=5000)
                except Exception:  # noqa: BLE001
                    pass
                try:
                    mut = page.evaluate("() => window.__audit ? window.__audit.mut : -1")
                except Exception:  # noqa: BLE001
                    mut = -1
                page.remove_listener("request", on_req)
                page.remove_listener("response", on_resp)
                page.remove_listener("dialog", on_dialog)
                ctx.remove_listener("page", on_popup)
                page.remove_listener("download", on_download)
                for pop in popups:
                    pop.close()
                navigated = page.url != before or mut == -1
                real_reqs = [r for r in reqs if r[2] in ("document", "xhr", "fetch", "websocket", "other")]
                effect = []
                if navigated:
                    effect.append(f"goes to {self.path(page.url)}")
                    if self.same_site(page.url):
                        found.append(self.path(page.url))
                if real_reqs:
                    effect.append("sends " + ", ".join(sorted({f"{m} {self.path(u)}" for m, u, _ in real_reqs}))[:120])
                if dialogs:
                    effect.append(f'shows dialog "{dialogs[0][:40]}"')
                if popups:
                    effect.append("opens a new tab")
                if downloads:
                    effect.append("downloads a file")
                if mut > 0 and not navigated:
                    effect.append("changes the page")
                bad = [s for s in resp_status if s[2] >= 400]
                expected = f"submits the form ({d['formMethod'].upper()} {d['formAction'] or 'same page'})" if in_form else "does something when clicked"
                if not effect:
                    self.row(vp, p, name, expected, "NOTHING happens: no navigation, no request, no page change", "BUG (dead button)")
                    effects.append(None)
                elif bad:
                    self.row(vp, p, name, expected, f"server answers HTTP {bad[0][2]} for {bad[0][0]} {self.path(bad[0][1])}",
                             "BUG (broken form)" if in_form else "BUG")
                    effects.append(None)
                else:
                    self.row(vp, p, name, expected, "; ".join(effect), "ok")
                    sig = tuple(sorted({(m, self.path(u)) for m, u, _ in real_reqs})) + (("nav", self.path(page.url)) if navigated else ())
                    effects.append(sig if real_reqs or navigated else None)
            except Exception as e:  # noqa: BLE001
                self.row(vp, p, name, "clickable", f"click failed: {str(e).splitlines()[0][:100]}", "BUG")
                effects.append(None)
        # ---- duplicates: same form + nothing that tells the buttons apart, or same handler, or same effect
        groups = {}
        for idx, d in enumerate(descs):
            if not d["visible"]:
                continue
            if d["formIndex"] >= 0 and d["type"] in ("submit", ""):
                key = ("form", d["formIndex"], d["formAction"], d["name"], d["value"] if d["name"] else "")
            elif d["onclick"]:
                key = ("onclick", re.sub(r"\s+", "", d["onclick"]))
            elif effects[idx]:
                key = ("effect", effects[idx])
            else:
                continue
            groups.setdefault(key, []).append(d)
        for key, ds in groups.items():
            if len(ds) > 1:
                names = " / ".join(f'"{d["text"] or d["value"] or d["id"]}"' for d in ds)
                why = {"form": "submit the same form with the same data", "onclick": "run the same onclick code",
                       "effect": "send the same request / go to the same place"}[key[0]]
                self.row(vp, p, f"buttons {names}", "each button does a different job", f"DUPLICATE: {len(ds)} buttons {why}",
                         "BUG (duplicate)")
        return found


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", default="audit-out")
    ap.add_argument("--start", nargs="*", default=[], help="extra paths to visit (pages no link points to)")
    ap.add_argument("--max-pages", type=int, default=40)
    ap.add_argument("--login-url")
    ap.add_argument("--username")
    ap.add_argument("--password-env", default="AUDIT_PASSWORD", help="name of the env variable holding the test password")
    ap.add_argument("--user-field", default="input[name=username], input[name=email], input[type=email], input[name=user], input[name=login]")
    ap.add_argument("--pass-field", default="input[type=password]")
    ap.add_argument("--skip", default=r"log ?out|sign ?out|delete account", help="regex of button/link texts NOT to click")
    ap.add_argument("--check-external", action="store_true", help="also request links to other sites")
    ap.add_argument("--wait-ms", type=int, default=700)
    ap.add_argument("--i-own-this", action="store_true")
    args = ap.parse_args()
    require_owned(args.base, args.i_own_this)
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        sys.exit("Playwright is missing. Run: pip install playwright && python -m playwright install chromium\n"
                 "If you cannot install it, do this step by hand with the browser tools and say so in NOT VERIFIED.")

    audit = Audit(args)
    started = time.time()
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for vp, size in VIEWPORTS.items():
            audit.run_viewport(browser, vp, size)
        browser.close()

    order = lambda r: (0 if r["status"].startswith("BUG") else 1 if r["status"] in ("slow", "check", "a11y", "NOT VERIFIED") else 2)  # noqa: E731
    merged = {}
    for r in audit.rows:  # the same menu link on 10 pages becomes one row
        key = (r["viewport"], r["element"], r["result"], r["status"])
        if key in merged:
            merged[key]["more"] += 1
        else:
            merged[key] = dict(r, more=0)
    for r in merged.values():
        if r.pop("more"):
            r["screen"] += " (and other pages)"
    rows = sorted(merged.values(), key=lambda r: (r["viewport"], order(r), r["screen"]))
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "ui_table.json"), "w", encoding="utf-8") as fh:
        json.dump(dict(rows=rows, pages={f"{k[0]} {k[1]}": v for k, v in audit.pages.items()}), fh, indent=2)
    md = ["# UI click test", "", f"Base: {args.base} - {len(rows)} checks in {time.time() - started:.0f}s", "",
          "| viewport | screen | element | expected | result | status | fixed? |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['viewport']} | {md_cell(r['screen'])} | {md_cell(r['element'])} | {md_cell(r['expected'])} | "
                  f"{md_cell(r['result'])} | {r['status']} | {'no' if r['status'].startswith('BUG') else '-'} |")
    md += ["", "## Page speed (local numbers, only a rough guide)", "", "| viewport + page | load ms | requests | KB |", "|---|---|---|---|"]
    for k, v in audit.pages.items():
        md.append(f"| {k[0]} {md_cell(k[1])} | {v['load_ms']} | {v['requests']} | {v['bytes'] // 1024} |")
    with open(os.path.join(args.out, "UI_TABLE.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    bugs = [r for r in rows if r["status"].startswith("BUG")]
    print("\n".join(l for l in md if "| BUG" in l or l.startswith(("#", "|---", "| viewport"))))
    print(f"\n{len(rows)} checks, {len(bugs)} bugs. Full table: {os.path.join(args.out, 'UI_TABLE.md')}")


if __name__ == "__main__":
    main()
