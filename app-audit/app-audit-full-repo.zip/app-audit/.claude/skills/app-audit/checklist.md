# App audit checklist

Go line by line. Each line ends as **PASS**, **FINDING**, **NOT APPLICABLE** (why) or
**NOT VERIFIED** (why). "Tool" names are scripts in `scripts/`.

Sources: OWASP Top 10:2025 (A01-A10), OWASP ASVS 5.0 (V1-V17), OWASP Cheat Sheet
Series (CS). Links are at the bottom.

Part 1 is the owner's original list. Part 2 was added from research. Section Z grows
with every audit.

---

## Part 1 - Backend (owner's list)

| ID | Check | How to test | Good looks like / fix | Source |
|---|---|---|---|---|
| B1 | Server language and framework | `map_app.py`; read dependency files. Is the version still supported (not end-of-life)? | Supported version, written down in AUDIT.md | A02, A03 |
| B2 | API layer (REST / GraphQL) | List every endpoint. REST: right verbs (GET never changes data), right status codes. GraphQL: introspection off in production, depth/cost limit, auth on every resolver | Every endpoint in the map, each with auth + validation | ASVS V4, CS REST Security, CS GraphQL |
| B3 | Database | Which engine? App user is not root/admin. DB not open to the internet (port bound to localhost / private network) | Least-privilege DB user, private network | A02, ASVS V13 |
| B4 | Indexes | Read the schema. Columns used in WHERE / JOIN / ORDER BY and all foreign keys have an index. Run `EXPLAIN` on the slowest queries. Look for N+1 queries (query inside a loop) | No full table scan on big tables | performance |
| B5 | Migrations | Is the schema in versioned migration files, or changed by hand? Can you build an empty DB from zero with one command? | Migration tool in use, files in git | A08 |
| B6 | Authentication | Passwords hashed with argon2id / bcrypt / scrypt (never plain, MD5, SHA1). Password min length 8+, no silly max. Same error for wrong user and wrong password. Safe password reset (random token, expires, one use). MFA offered for admins | Strong hash + safe reset | A07, ASVS V6, CS Authentication, CS Password Storage, CS Forgot Password |
| B7 | Authorization | Every route: needs login? needs a role? Checks are on the **server**, not only hidden buttons. Deny by default. See S5 for the A-reads-B test | Central check (decorator / middleware) on every route | A01, ASVS V8, CS Authorization |
| B8 | Encryption in transit | HTTPS everywhere, HTTP redirects to HTTPS, TLS 1.2+, DB and API connections also encrypted. Local test cannot prove this: ask the owner or test the live URL (with permission) | HTTPS + HSTS (see S3) | A04, ASVS V12, CS Transport Layer Security |
| B9 | Encryption at rest | Disk / DB encryption on the host. Sensitive fields (ID numbers, tokens, health data) encrypted in the DB. Keys not stored next to the data | Provider encryption on; app-level for the most sensitive fields | A04, ASVS V11, V14, CS Cryptographic Storage |
| B10 | SQL injection | `scan_code.py` (SQLI leads) + `probe_inputs.py` on every form and URL parameter. Read every query built with f-strings, `+`, `%`, `.format`, template strings. Also ORDER BY / table names from input | Parameterized queries everywhere; allow-list for column names | A05, ASVS V1, CS SQL Injection Prevention, CS Query Parameterization |
| B11 | XSS (reflected, stored, DOM) | `scan_code.py` (XSS leads) + `probe_inputs.py` (use `--view` for stored). Look for `\|safe`, `innerHTML`, `v-html`, `dangerouslySetInnerHTML`, `<%- %>`, `{!! !!}` | Auto-escaping on, no raw HTML from users, CSP as second wall | A05, ASVS V1, V3, CS XSS Prevention, CS DOM XSS Prevention |
| B12 | CSRF | Every form/endpoint that changes data: has a CSRF token **and** the server rejects a request without it (send the POST without the token: must fail). Cookies `SameSite=Lax` or `Strict`. GET never changes data (logout by GET is a small CSRF too) | Token checked on the server + SameSite cookie | A01, ASVS V3, CS CSRF Prevention |
| B13 | Caching | Private pages send `Cache-Control: no-store` (or `private`). Static files have long cache + hashed names. No user data in a shared cache key | Private data never cached by proxies/CDN | ASVS V14 |
| B14 | CDN | Is there one? Third-party scripts loaded with `integrity=` (SRI) and pinned versions. CDN does not cache logged-in pages | SRI on every external script/style | A03, A08, CS Third Party JavaScript |
| B15 | Background jobs | Which jobs exist (email, cleanup, reports)? Do they retry safely, have a timeout, and log failures? Is job input validated like API input? | Failures visible, no secret data in job arguments | A10 |
| B16 | Logging and monitoring | Logins (ok and failed), access-denied, admin actions and errors are logged with time + user id. **No** passwords, tokens or full card numbers in logs. Someone gets an alert on error spikes | Security events logged, alert exists | A09, ASVS V16, CS Logging, CS Logging Vocabulary |
| B17 | Backups and recovery | Ask the owner: automatic backups? how often? stored somewhere else? encrypted? **Has a restore ever been tested?** | Daily automatic backup, off-site, restore tested | resilience |

---

## Part 2 - Added from research

### Security

| ID | Check | How to test | Good looks like / fix | Source |
|---|---|---|---|---|
| S1 | Input validation | Every input checked on the **server**: type, length, range, format, allow-list. Send too-long text, negative numbers, wrong types, missing fields. Client-side checks alone do not count | Validation schema (pydantic, zod, marshmallow...) on every endpoint; clear 400 error | A05, A06, ASVS V2, CS Input Validation |
| S2 | Rate limiting and login lockout | `check_http.py --lockout-test 12`. Also: signup, password reset, contact form, expensive search, any endpoint that sends email/SMS | Limit per IP and per account; slow down or lock after about 5-10 bad logins; HTTP 429 | A07, A06, ASVS V6, V2, CS Authentication, CS Credential Stuffing Prevention |
| S3 | Security headers | `check_http.py`. Content-Security-Policy (no `unsafe-inline` for scripts), Strict-Transport-Security, X-Content-Type-Options: nosniff, frame-ancestors / X-Frame-Options, Referrer-Policy, Permissions-Policy | All set by one middleware | A02, ASVS V3, CS HTTP Headers, CS Content Security Policy |
| S4 | Session and cookie safety | `check_http.py --login`. Cookie flags HttpOnly, Secure, SameSite. New session id after login. Logout really ends the session on the server. Sessions expire (idle + absolute). Tokens never in the URL. JWT: signature checked, `alg` fixed, short expiry | Flags set, id rotates on login, server-side logout | A07, ASVS V7, V9, CS Session Management, CS JSON Web Token |
| S5 | Broken access control (can user A read user B's data?) | `access_check.py` with ids owned by A, tested as B and as nobody. Do the same by hand for edit/delete. Try a normal user on admin URLs. Try changing `user_id` / `role` fields in a request body (mass assignment) | Every query that loads an item also checks the owner; role checks on the server | A01, ASVS V8, CS Authorization, CS IDOR Prevention, CS Mass Assignment |
| S6 | CORS | `check_http.py` sends `Origin: https://evil.example`. Must not be reflected. `*` only for fully public data, never with credentials | Exact allow-list of origins | A02, ASVS V3 |
| S7 | File uploads | Upload: wrong type with a renamed extension, a huge file, a name like `../../x.php`, an HTML/SVG file. Where are files stored and served from? | Allow-list of extensions + content check, size limit, random new name, stored outside the web root, served as download | A05, A06, ASVS V5, CS File Upload |
| S8 | Secrets in code or git history | `scan_code.py` (code + full git history). Also check `.env` is in `.gitignore`, and client-side JS bundles for keys | No secret in the repo, ever. Found one -> rotate it | A02, A04, ASVS V13, CS Secrets Management |
| S9 | Vulnerable and outdated dependencies | `pip-audit` / `npm audit` / `composer audit` / `bundle audit`. Lock file exists and is in git. Dependabot or similar on | 0 known high/critical; lock file committed | A03, ASVS V15, CS Vulnerable Dependency Management |
| S10 | Error messages that leak details | `check_http.py` + `probe_inputs.py`. Cause a 404 and a 500: no stack trace, SQL text, file paths or versions shown. Debug mode off. Does the app "fail closed" (an error never logs you in or skips a check)? | Generic error page, details only in server logs | A10, A02, ASVS V16, CS Error Handling |
| S11 | Admin audit log | Admin and sensitive actions (role change, delete user, export data, config change) are written to a log with who / what / when, and normal admins cannot edit that log | Append-only audit table or log | A09, ASVS V16 |
| S12 | Open redirect and SSRF | Parameters like `next=`, `url=`, `redirect=`, `callback=`: try an outside address. Server-side fetch of a user URL: try `http://127.0.0.1` | Redirect only to own paths; fetch only allow-listed hosts | A01, CS Unvalidated Redirects, CS SSRF Prevention |
| S13 | Command injection, path traversal, unsafe deserialization | `scan_code.py` (RCE, PATH leads): `eval`, `exec`, `shell=True`, `pickle`, `yaml.load`, file paths built from input | No user input in shell, eval, file paths or deserializers | A05, A08, CS OS Command Injection Defense, CS Deserialization |
| S14 | Security misconfiguration | Debug off, default passwords changed, directory listing off, admin tools (phpMyAdmin, /debug, /.git, /.env) not reachable, only needed ports open | Production config separate from dev config | A02, ASVS V13 |
| S15 | Sensitive data exposure in responses | Look at API answers: do they send fields the page does not need (password hash, email of other users, internal ids)? | Return only needed fields | A01, A04, ASVS V14, CS REST Security |
| S16 | Business logic abuse | Think like a cheater: negative quantity, change the price in the request, skip a step, do an action twice fast (race), reuse a one-time code | Server re-checks every value and step | A06, ASVS V2, CS Abuse Case |

### Privacy (GDPR basics - you are in the EU)

| ID | Check | How to test | Good looks like | Source |
|---|---|---|---|---|
| P1 | Privacy policy | Is there a page that says what data is collected, why, for how long, and who to contact? | Linked from every page footer and from signup | GDPR art. 13 |
| P2 | Cookie consent | Any tracking/analytics/ads cookies set **before** the user says yes? (look at cookies on first load) | Only needed cookies before consent; reject as easy as accept | ePrivacy, AEPD cookie guide |
| P3 | Data minimisation | Does each form ask only for what is needed? | No unused personal fields | GDPR art. 5 |
| P4 | User rights | Can a user see/export their data and delete their account? | Export + delete exist (or a documented manual way) | GDPR art. 15-20 |
| P5 | Personal data in logs / third parties | Emails, IPs, names in logs or sent to outside services (analytics, error trackers, AI APIs)? | Minimal, listed in the privacy policy | GDPR art. 5, 28, CS User Privacy Protection |

### Quality

| ID | Check | How to test | Good looks like | Source |
|---|---|---|---|---|
| Q1 | Accessibility | `click_audit.py` (labels, alt text, lang, names, tap size). By hand: use the whole app with **keyboard only** (Tab, Enter, Esc), visible focus ring, colour contrast 4.5:1, zoom to 200%. Lighthouse or axe if available | WCAG 2.2 level AA basics pass | WCAG 2.2 |
| Q2 | Page speed | `click_audit.py` page table (rough). Better: Lighthouse on the main pages. Big images, no compression, render-blocking scripts, no caching | LCP under 2.5 s, page under about 1 MB, images sized and lazy-loaded | Core Web Vitals |
| Q3 | Test coverage | Do tests exist? Run them with coverage (`pytest --cov`, `jest --coverage`). Are login, permissions and the main money/data paths tested? | Tests for every critical path; each fixed bug gets a test | ASVS V15 |
| Q4 | CI on every push | `.github/workflows/` (or other CI) runs tests + linter + dependency audit on every push and pull request. Main branch protected | Green check needed before merge | A03, A08, CS CI/CD Security |
| Q5 | UI works at 1440px and 390px | `click_audit.py`: dead buttons, duplicate buttons, dead links, broken forms, console errors, sideways scroll | Full table has no BUG rows | - |
| Q6 | Project hygiene | README says how to run it. `.gitignore` covers `.env`, databases, `node_modules`, `audit-out`. `.env.example` exists without real values | New person can start the app from the README | A02 |

---

## Z - Added during audits

When an audit finds something no line above covers, add it here so it stays.
Format: `| Z<n> | check | how to test | good looks like | source | date, app |`

| ID | Check | How to test | Good looks like | Source | Added |
|---|---|---|---|---|---|
| Z1 | State-changing GET links (logout, delete, "mark as...") | In the map, find GET routes that change something. Any page (even another site, with an `<img>` tag) can trigger them | Use POST + CSRF token for every change, logout included | A01, CS CSRF Prevention | 2026-11-10, sample app NoteBox |
| Z2 | Seed / demo accounts with known passwords | Read seed scripts and README for default users. Can they log in on the real site? | Seed data only loads in dev; no default accounts in production | A02, A07 | 2026-11-10, sample app NoteBox |

---

## Sources

- OWASP Top 10:2025 - https://owasp.org/Top10/2025/
  A01 Broken Access Control, A02 Security Misconfiguration, A03 Software Supply Chain
  Failures, A04 Cryptographic Failures, A05 Injection, A06 Insecure Design,
  A07 Authentication Failures, A08 Software or Data Integrity Failures,
  A09 Security Logging and Alerting Failures, A10 Mishandling of Exceptional Conditions
- OWASP ASVS 5.0 - https://github.com/OWASP/ASVS
  V1 Encoding and Sanitization, V2 Validation and Business Logic, V3 Web Frontend
  Security, V4 API and Web Service, V5 File Handling, V6 Authentication, V7 Session
  Management, V8 Authorization, V9 Self-contained Tokens, V10 OAuth and OIDC,
  V11 Cryptography, V12 Secure Communication, V13 Configuration, V14 Data Protection,
  V15 Secure Coding and Architecture, V16 Security Logging and Error Handling, V17 WebRTC
- OWASP Cheat Sheet Series ("CS <name>") - https://cheatsheetseries.owasp.org/
- WCAG 2.2 - https://www.w3.org/TR/WCAG22/
